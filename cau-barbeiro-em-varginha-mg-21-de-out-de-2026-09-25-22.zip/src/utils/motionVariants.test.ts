import test from 'node:test';
import assert from 'node:assert/strict';
import { getFadeInUpVariants, LUXURY_EASING } from './motionVariants.ts';

test('getFadeInUpVariants returns default distance and easing', () => {
  const variants = getFadeInUpVariants();
  assert.equal(variants.initial.opacity, 0);
  assert.equal(variants.initial.y, 28);
  assert.equal(variants.animate.opacity, 1);
  assert.equal(variants.animate.y, 0);
  assert.equal(variants.transition.duration, 0.7);
  assert.equal(variants.transition.delay, 0);
  assert.deepEqual(variants.transition.ease, LUXURY_EASING);
});

test('getFadeInUpVariants honors reduced motion by eliminating y-translation', () => {
  const variants = getFadeInUpVariants({ reducedMotion: true });
  assert.equal(variants.initial.opacity, 0);
  assert.equal(variants.initial.y, 0);
  assert.equal(variants.transition.duration, 0.2);
});

test('getFadeInUpVariants applies custom options correctly', () => {
  const variants = getFadeInUpVariants({ distance: 40, duration: 1.0, delay: 0.15 });
  assert.equal(variants.initial.y, 40);
  assert.equal(variants.transition.duration, 1.0);
  assert.equal(variants.transition.delay, 0.15);
});
