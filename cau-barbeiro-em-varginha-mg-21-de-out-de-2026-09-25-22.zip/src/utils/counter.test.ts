import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateEasedValue, formatCounterNumber } from './counter.ts';

test('calculateEasedValue returns 0 at progress 0', () => {
  assert.equal(calculateEasedValue(0, 1200), 0);
});

test('calculateEasedValue returns target at progress 1', () => {
  assert.equal(calculateEasedValue(1, 1200), 1200);
});

test('calculateEasedValue calculates progressive eased values', () => {
  const midVal = calculateEasedValue(0.5, 1000);
  assert.ok(midVal > 500); // EaseOut is front-loaded
  assert.ok(midVal < 1000);
});

test('formatCounterNumber formats thousands with dot in pt-BR', () => {
  const formatted = formatCounterNumber(1200);
  assert.equal(formatted, '1.200');
  assert.equal(formatCounterNumber(500), '500');
});
