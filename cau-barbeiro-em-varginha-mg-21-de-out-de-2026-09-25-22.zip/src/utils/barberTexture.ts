/**
 * Realistic seamless barber pole texture math and canvas generation.
 */

export interface BarberTextureConfig {
  width?: number;
  height?: number;
  cycles?: number;
}

export interface PixelRGB {
  r: number;
  g: number;
  b: number;
  stripeType: 'red' | 'blue' | 'white';
}

/**
 * Pure calculation function for deterministic unit testing and canvas generation.
 * Calculates RGB values and stripe type for any (x, y) coordinate.
 */
export function calculateBarberStripePixel(
  x: number,
  y: number,
  width: number = 1024,
  height: number = 1024,
  cycles: number = 2
): PixelRGB {
  const period = width / cycles;

  // 100% seamless diagonal wrapping: (x - y) mod period
  let s = (x - y) % period;
  if (s < 0) s += period;

  const normS = s / period; // 0 to 1
  const stripeIndex = Math.floor(normS * 4);
  const stripeFrac = normS * 4 - stripeIndex; // 0 to 1 within stripe

  const redBase = [196, 18, 42];
  const redHighlight = [230, 42, 65];
  const redShadow = [128, 12, 28];

  const blueBase = [12, 59, 136];
  const blueHighlight = [28, 92, 205];
  const blueShadow = [7, 33, 80];

  const whiteBase = [248, 250, 252];
  const whiteHighlight = [255, 255, 255];
  const whiteShadow = [205, 215, 226];

  const centerFactor = Math.sin(stripeFrac * Math.PI);
  const edgeFactor = Math.pow(Math.sin(stripeFrac * Math.PI), 0.35);

  let r = 255;
  let g = 255;
  let b = 255;
  let stripeType: 'red' | 'blue' | 'white' = 'white';

  if (stripeIndex === 0) {
    stripeType = 'red';
    r = interpolate(redShadow[0], redBase[0], edgeFactor) + (redHighlight[0] - redBase[0]) * centerFactor * 0.6;
    g = interpolate(redShadow[1], redBase[1], edgeFactor) + (redHighlight[1] - redBase[1]) * centerFactor * 0.6;
    b = interpolate(redShadow[2], redBase[2], edgeFactor) + (redHighlight[2] - redBase[2]) * centerFactor * 0.6;
  } else if (stripeIndex === 2) {
    stripeType = 'blue';
    r = interpolate(blueShadow[0], blueBase[0], edgeFactor) + (blueHighlight[0] - blueBase[0]) * centerFactor * 0.6;
    g = interpolate(blueShadow[1], blueBase[1], edgeFactor) + (blueHighlight[1] - blueBase[1]) * centerFactor * 0.6;
    b = interpolate(blueShadow[2], blueBase[2], edgeFactor) + (blueHighlight[2] - blueBase[2]) * centerFactor * 0.6;
  } else {
    stripeType = 'white';
    r = interpolate(whiteShadow[0], whiteBase[0], edgeFactor) + (whiteHighlight[0] - whiteBase[0]) * centerFactor * 0.3;
    g = interpolate(whiteShadow[1], whiteBase[1], edgeFactor) + (whiteHighlight[1] - whiteBase[1]) * centerFactor * 0.3;
    b = interpolate(whiteShadow[2], whiteBase[2], edgeFactor) + (whiteHighlight[2] - whiteBase[2]) * centerFactor * 0.3;
  }

  // Micro-seam indentation at stripe borders
  const seamDist = Math.min(stripeFrac, 1 - stripeFrac) * 4;
  if (seamDist < 0.08) {
    const seamDarkness = 1 - (1 - seamDist / 0.08) * 0.35;
    r *= seamDarkness;
    g *= seamDarkness;
    b *= seamDarkness;
  }

  const normY = Math.sin((y / height) * Math.PI);
  const backGlow = 0.92 + normY * 0.16;

  return {
    r: Math.min(255, Math.max(0, Math.round(r * backGlow))),
    g: Math.min(255, Math.max(0, Math.round(g * backGlow))),
    b: Math.min(255, Math.max(0, Math.round(b * backGlow))),
    stripeType,
  };
}

function interpolate(a: number, b: number, t: number): number {
  return a + (b - a) * Math.max(0, Math.min(1, t));
}

/**
 * Generates an HTMLCanvasElement populated with the realistic barber pole pattern.
 */
export function generateRealisticBarberCanvas(config: BarberTextureConfig = {}): HTMLCanvasElement {
  const { width = 1024, height = 1024, cycles = 2 } = config;

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) return canvas;

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const p = calculateBarberStripePixel(x, y, width, height, cycles);
      const idx = (y * width + x) * 4;
      data[idx] = p.r;
      data[idx + 1] = p.g;
      data[idx + 2] = p.b;
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(imgData, 0, 0);

  // Soft vertical specular gloss reflection
  const glossGrad = ctx.createLinearGradient(0, 0, width, 0);
  glossGrad.addColorStop(0, 'rgba(255, 255, 255, 0.0)');
  glossGrad.addColorStop(0.35, 'rgba(255, 255, 255, 0.08)');
  glossGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0.22)');
  glossGrad.addColorStop(0.65, 'rgba(255, 255, 255, 0.08)');
  glossGrad.addColorStop(1, 'rgba(255, 255, 255, 0.0)');
  ctx.fillStyle = glossGrad;
  ctx.fillRect(0, 0, width, height);

  return canvas;
}
