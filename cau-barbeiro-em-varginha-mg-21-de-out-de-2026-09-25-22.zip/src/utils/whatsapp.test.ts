import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildWhatsAppLink,
  getBookingMessage,
  buildCustomBookingMessage,
  formatPrice,
  formatDuration,
  CAUA_PHONE,
} from './whatsapp.ts';

test('buildWhatsAppLink sanitizes number and encodes text', () => {
  const link = buildWhatsAppLink('Olá Cauã! Quero agendar.', '+55 (35) 98884-2698');
  assert.equal(
    link,
    'https://wa.me/5535988842698?text=Ol%C3%A1%20Cau%C3%A3!%20Quero%20agendar.'
  );
});

test('buildWhatsAppLink uses default phone number when omitted', () => {
  const link = buildWhatsAppLink('Teste');
  assert.ok(link.includes(CAUA_PHONE));
  assert.ok(link.startsWith('https://wa.me/5535988842698?text='));
});

test('getBookingMessage handles general inquiry and specific service', () => {
  const general = getBookingMessage();
  assert.ok(general.includes('Olá, Cauã!'));
  assert.ok(general.includes('consultar os horários disponíveis'));

  const specific = getBookingMessage('Degradê Navalhado');
  assert.ok(specific.includes('Degradê Navalhado'));
  assert.ok(specific.includes('Quais os próximos horários disponíveis?'));
});

test('buildCustomBookingMessage creates clean multi-service client request', () => {
  const msg = buildCustomBookingMessage({
    serviceNames: ['Corte Degradê', 'Barba Terapia'],
    totalPrice: 60,
    totalDurationMinutes: 80,
    periodPreference: 'tarde',
  });

  assert.ok(msg.includes('Corte Degradê + Barba Terapia'));
  assert.ok(msg.includes('Tarde'));
  assert.ok(msg.includes('60'));
  assert.ok(msg.includes('R$'));
  assert.ok(msg.includes('Tem vaga disponível'));
});

test('formatPrice formats BRL numbers and handles consultar', () => {
  assert.equal(formatPrice('consultar'), 'Consultar');
  const priceFormatted = formatPrice(35);
  assert.ok(priceFormatted.includes('35'));
  assert.ok(priceFormatted.includes('R$'));
});

test('formatDuration formats minutes and hours cleanly', () => {
  assert.equal(formatDuration(undefined), null);
  assert.equal(formatDuration(0), null);
  assert.equal(formatDuration(45), '45 min');
  assert.equal(formatDuration(60), '1h');
  assert.equal(formatDuration(75), '1h 15min');
});
