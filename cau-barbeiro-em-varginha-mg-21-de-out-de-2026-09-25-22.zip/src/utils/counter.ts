/**
 * Math and formatting utilities for animated counters
 */

/**
 * Calculates current animated value using easeOutExpo curve
 * @param progress number between 0 and 1
 * @param target final integer value
 */
export function calculateEasedValue(progress: number, target: number): number {
  if (progress <= 0) return 0;
  if (progress >= 1) return target;
  // EaseOutExpo: 1 - Math.pow(2, -10 * progress)
  const easedProgress = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
  return Math.round(easedProgress * target);
}

/**
 * Formats integer with Brazilian Portuguese thousands separator (e.g. 1200 -> 1.200)
 */
export function formatCounterNumber(value: number): string {
  return new Intl.NumberFormat('pt-BR').format(value);
}
