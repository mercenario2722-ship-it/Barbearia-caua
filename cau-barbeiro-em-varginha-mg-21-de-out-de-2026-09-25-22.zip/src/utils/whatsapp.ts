/**
 * WhatsApp integration & booking utilities for Barbearia do Cauã
 */

export const CAUA_PHONE = '5535988842698';
export const CAUA_DISPLAY_PHONE = '+55 (35) 98884-2698';
export const CAUA_LOCATION_NAME = 'Park Rinald, Varginha — MG';
export const CAUA_LOCATION_MAPS_URL = 'https://www.google.com/maps/search/?api=1&query=Park+Rinald+Varginha+MG';

export interface ServiceItem {
  id: string;
  name: string;
  category: 'cabelo' | 'barba' | 'combo' | 'acabamento';
  description: string;
  price: number | 'consultar';
  durationMinutes?: number;
  highlight?: boolean;
}

export interface CustomBookingRequest {
  serviceNames: string[];
  totalPrice: number;
  totalDurationMinutes: number;
  periodPreference?: 'manha' | 'tarde' | 'noite' | 'qualquer';
  preferredDay?: string;
}

/**
 * Generates an official WhatsApp click-to-chat URL with pre-filled message
 */
export function buildWhatsAppLink(
  message: string,
  phoneNumber: string = CAUA_PHONE
): string {
  const sanitizedNumber = phoneNumber.replace(/\D/g, '');
  const encodedText = encodeURIComponent(message.trim());
  return `https://wa.me/${sanitizedNumber}?text=${encodedText}`;
}

/**
 * Generates specific booking message for general inquiry or service selection
 */
export function getBookingMessage(serviceName?: string): string {
  if (serviceName) {
    return `Olá, Cauã! Gostaria de agendar o serviço de *${serviceName}*. Quais os próximos horários disponíveis?`;
  }
  return 'Olá, Cauã! Vi seu site e gostaria de consultar os horários disponíveis para um corte. Como funciona o agendamento?';
}

/**
 * Generates a human, customized booking message when client selects multiple services
 */
export function buildCustomBookingMessage(request: CustomBookingRequest): string {
  const servicesList = request.serviceNames.length > 0
    ? request.serviceNames.join(' + ')
    : 'Corte Degradê';

  const periodMap: Record<string, string> = {
    manha: 'Manhã',
    tarde: 'Tarde',
    noite: 'Final de tarde',
    qualquer: 'Qualquer horário disponível',
  };

  const periodText = request.periodPreference
    ? periodMap[request.periodPreference] || 'A combinar'
    : 'A combinar';

  const durationStr = formatDuration(request.totalDurationMinutes) || '45 min';
  const priceStr = formatPrice(request.totalPrice);

  return `Opa, Cauã! Estive no seu site e gostaria de agendar:
• Serviços: *${servicesList}*
• Horário preferido: ${periodText}
• Previsão: ${priceStr} (${durationStr})

Tem vaga disponível para esses dias?`;
}

/**
 * Formats Brazilian Real currency or returns 'Consultar'
 */
export function formatPrice(price: number | 'consultar'): string {
  if (price === 'consultar') {
    return 'Consultar';
  }
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(price);
}

/**
 * Formats duration in minutes into friendly PT-BR text
 */
export function formatDuration(minutes?: number): string | null {
  if (!minutes || minutes <= 0) return null;
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  if (remainingMinutes === 0) return `${hours}h`;
  return `${hours}h ${remainingMinutes}min`;
}
