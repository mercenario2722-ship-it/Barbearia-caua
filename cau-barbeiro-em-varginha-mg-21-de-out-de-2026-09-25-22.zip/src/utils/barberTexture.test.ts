import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateBarberStripePixel } from './barberTexture.ts';

test('calculateBarberStripePixel wraps seamlessly across X boundaries', () => {
  const width = 1024;
  const height = 1024;
  for (const y of [0, 256, 512, 768, 1023]) {
    const left = calculateBarberStripePixel(0, y, width, height, 2);
    const right = calculateBarberStripePixel(width, y, width, height, 2);
    assert.equal(left.stripeType, right.stripeType, `Stripe type should match at y=${y}`);
    assert.equal(left.r, right.r, `Red value should wrap seamlessly at y=${y}`);
    assert.equal(left.g, right.g, `Green value should wrap seamlessly at y=${y}`);
    assert.equal(left.b, right.b, `Blue value should wrap seamlessly at y=${y}`);
  }
});

test('calculateBarberStripePixel wraps seamlessly across Y boundaries', () => {
  const width = 1024;
  const height = 1024;
  for (const x of [0, 256, 512, 768, 1023]) {
    const top = calculateBarberStripePixel(x, 0, width, height, 2);
    const bottom = calculateBarberStripePixel(x, height, width, height, 2);
    assert.equal(top.stripeType, bottom.stripeType, `Stripe type should match at x=${x}`);
    // Note: slight Y backGlow difference across height is smooth, but stripe type matches
  }
});

test('calculateBarberStripePixel cycles through red, white, blue, white in order', () => {
  const width = 1024;
  const period = width / 2; // 512
  const quarter = period / 4; // 128

  const pRed = calculateBarberStripePixel(quarter * 0.5, 0, width, width, 2);
  const pWhite1 = calculateBarberStripePixel(quarter * 1.5, 0, width, width, 2);
  const pBlue = calculateBarberStripePixel(quarter * 2.5, 0, width, width, 2);
  const pWhite2 = calculateBarberStripePixel(quarter * 3.5, 0, width, width, 2);

  assert.equal(pRed.stripeType, 'red');
  assert.equal(pWhite1.stripeType, 'white');
  assert.equal(pBlue.stripeType, 'blue');
  assert.equal(pWhite2.stripeType, 'white');

  // Red pixel should have dominant red channel
  assert.ok(pRed.r > pRed.g && pRed.r > pRed.b);
  // Blue pixel should have dominant blue channel
  assert.ok(pBlue.b > pBlue.r && pBlue.b > pBlue.g);
  // White pixel should have balanced high RGB
  assert.ok(pWhite1.r > 190 && pWhite1.g > 190 && pWhite1.b > 190);
});
