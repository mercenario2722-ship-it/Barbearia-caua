export interface FadeInUpOptions {
  distance?: number;
  duration?: number;
  delay?: number;
  reducedMotion?: boolean;
}

export const LUXURY_EASING: [number, number, number, number] = [0.22, 1, 0.36, 1];

/**
 * Builds deterministic motion variants for subtle fade-in-up entrance animations.
 * Honors accessibility by eliminating translation when reducedMotion is active.
 */
export function getFadeInUpVariants(options: FadeInUpOptions = {}) {
  const {
    distance = 28,
    duration = 0.7,
    delay = 0,
    reducedMotion = false,
  } = options;

  return {
    initial: {
      opacity: 0,
      y: reducedMotion ? 0 : distance,
    },
    animate: {
      opacity: 1,
      y: 0,
    },
    transition: {
      duration: reducedMotion ? 0.2 : duration,
      delay,
      ease: LUXURY_EASING,
    },
  };
}
