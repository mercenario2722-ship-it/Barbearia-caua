import React, { useState } from 'react';
import { SERVICES, Service } from '../data/barbershop.ts';
import { formatPrice, formatDuration, buildWhatsAppLink, getBookingMessage } from '../utils/whatsapp.ts';
import { Clock, MessageCircle, Star, Sparkles } from 'lucide-react';
import { TiltCard } from './TiltCard.tsx';
import { BookingCustomizer } from './BookingCustomizer.tsx';
import { FadeInUp } from './FadeInUp.tsx';

export const Services: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'Todos os Serviços' },
    { id: 'corte', label: 'Cabelo' },
    { id: 'barba', label: 'Barba' },
    { id: 'combo', label: 'Combos' },
    { id: 'acabamento', label: 'Acabamento' },
  ];

  const filteredServices = activeCategory === 'all'
    ? SERVICES
    : SERVICES.filter((s) => s.category === activeCategory);

  return (
    <section id="servicos" className="py-28 bg-[#09090c]/50 backdrop-blur-[1px] border-t border-zinc-900/80 relative scroll-mt-20 overflow-hidden">
      {/* Ambient lighting accents */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div 
          className="absolute top-1/3 right-1/4 w-[500px] h-[500px] bg-[#c5a059]/5 rounded-full blur-[140px]" 
          aria-hidden="true" 
        />
      </div>

      <FadeInUp>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900/80 border border-zinc-800 text-[#c5a059] text-xs font-semibold tracking-[0.2em] uppercase mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Cardápio Autoral</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Serviços & Procedimentos
            </h2>
          </div>
          <p className="text-zinc-300 text-sm sm:text-base max-w-md leading-relaxed">
            Escolha o atendimento ideal para sua rotina. Cada serviço inclui higienização, consultoria e finalização com produtos de linha profissional.
          </p>
        </div>

        {/* Interactive Glass Filter Tabs */}
        <div className="flex flex-wrap items-center gap-2 mb-10 pb-2 border-b border-zinc-800/60">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-all whitespace-nowrap focus:outline-none focus-visible:ring-1 focus-visible:ring-[#c5a059] ${
                activeCategory === cat.id
                  ? 'bg-gradient-to-r from-[#e5c278] to-[#c5a059] text-zinc-950 shadow-[0_4px_15px_rgba(197,160,89,0.25)] font-bold'
                  : 'text-zinc-300 hover:text-white bg-zinc-900/70 hover:bg-zinc-800/80 border border-zinc-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Services List with 3D Tilt Panels */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServices.map((service: Service) => {
            const bookingUrl = buildWhatsAppLink(getBookingMessage(service.name));
            const durationText = formatDuration(service.durationMinutes);

            return (
              <TiltCard
                key={service.id}
                maxTilt={6}
                glare={true}
                scale={1.02}
                className="h-full"
              >
                <div
                  className={`h-full p-7 rounded-2xl bg-zinc-950/80 backdrop-blur-xl border transition-all duration-300 flex flex-col justify-between relative shadow-[0_10px_30px_-10px_rgba(0,0,0,0.6)] ${
                    service.featured
                      ? 'border-[#c5a059]/40 shadow-[0_10px_35px_-5px_rgba(197,160,89,0.15)]'
                      : 'border-zinc-800/80 hover:border-zinc-700'
                  }`}
                >
                  {service.featured && (
                    <div className="absolute top-4 right-4 flex items-center gap-1 text-[10px] font-bold tracking-widest uppercase text-[#c5a059] bg-[#c5a059]/15 border border-[#c5a059]/40 px-2.5 py-0.5 rounded-full">
                      <Star className="w-3 h-3 fill-[#c5a059]" />
                      <span>Destaque</span>
                    </div>
                  )}

                  <div>
                    {/* Metadata */}
                    <div className="flex items-center gap-2 text-xs text-zinc-400 mb-2 font-medium">
                      <span>{service.categoryLabel}</span>
                      {durationText && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="flex items-center gap-1 text-zinc-300">
                            <Clock className="w-3.5 h-3.5 text-[#c5a059]" />
                            <span className="tabular-nums">{durationText}</span>
                          </span>
                        </>
                      )}
                    </div>

                    <h3 className="font-heading text-xl font-bold text-white mb-2.5 group-hover:text-[#c5a059] transition-colors">
                      {service.name}
                    </h3>

                    <p className="text-zinc-400 text-sm leading-relaxed mb-6 font-normal">
                      {service.description}
                    </p>
                  </div>

                  <div className="pt-6 border-t border-zinc-800/70 flex items-center justify-between gap-4 mt-auto">
                    <div>
                      <span className="text-[10px] uppercase tracking-wider text-zinc-400 block font-semibold">
                        Investimento
                      </span>
                      <span className="font-heading text-2xl font-extrabold text-white tabular-nums">
                        {formatPrice(service.price)}
                      </span>
                    </div>

                    <a
                      href={bookingUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-zinc-950 bg-gradient-to-r from-[#e5c278] via-[#c5a059] to-[#b38e47] hover:brightness-110 active:scale-[0.98] rounded-sm transition-all shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-[#c5a059]"
                      aria-label={`Agendar ${service.name} no WhatsApp`}
                    >
                      <MessageCircle className="w-3.5 h-3.5 fill-current" />
                      <span>Agendar</span>
                    </a>
                  </div>
                </div>
              </TiltCard>
            );
          })}
        </div>

        {/* Interactive Multi-Service Booking Customizer */}
        <BookingCustomizer />

        {/* Custom inquiry note */}
        <div className="mt-12 p-6 rounded-2xl bg-zinc-950/70 backdrop-blur-md border border-zinc-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left shadow-lg">
          <div>
            <p className="text-white text-sm font-bold">
              Tem alguma dúvida sobre qual estilo combina com você?
            </p>
            <p className="text-zinc-400 text-xs mt-1">
              Fale diretamente com o Cauã no WhatsApp para tirar dúvidas antes de agendar seu horário.
            </p>
          </div>
          <a
            href={buildWhatsAppLink('Olá, Cauã! Gostaria de consultar sobre um corte específico que tenho em mente.')}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#c5a059] hover:text-[#e5c278] border-b border-[#c5a059] pb-0.5 whitespace-nowrap"
          >
            <span>Consultar dúvida com Cauã</span>
            <span aria-hidden="true">&rarr;</span>
          </a>
        </div>
      </div>
      </FadeInUp>
    </section>
  );
};
