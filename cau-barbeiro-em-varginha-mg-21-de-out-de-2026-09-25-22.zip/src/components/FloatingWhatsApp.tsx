import React from 'react';
import { MessageCircle } from 'lucide-react';
import { buildWhatsAppLink, getBookingMessage } from '../utils/whatsapp.ts';

export const FloatingWhatsApp: React.FC = () => {
  const whatsappUrl = buildWhatsAppLink(getBookingMessage());

  return (
    <aside aria-label="Acesso rápido WhatsApp" className="fixed bottom-6 right-6 z-40">
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-[#25D366] text-white shadow-2xl hover:scale-110 active:scale-95 transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-[#25D366]/40"
        aria-label="Abrir conversa no WhatsApp para agendar corte com Cauã"
      >
        {/* Subtle breathing ripple */}
        <span 
          className="absolute inset-0 rounded-full bg-[#25D366]/40 animate-ping pointer-events-none" 
          aria-hidden="true"
        />

        <MessageCircle className="w-7 h-7 fill-current relative z-10" />

        {/* Floating tooltip */}
        <span className="hidden sm:inline-block absolute right-16 px-3 py-1.5 rounded bg-zinc-900/95 text-white text-xs font-semibold whitespace-nowrap shadow-xl border border-zinc-800 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          Agendar no WhatsApp
        </span>
      </a>
    </aside>
  );
};
