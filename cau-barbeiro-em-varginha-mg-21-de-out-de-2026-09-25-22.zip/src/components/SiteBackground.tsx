import React from 'react';

/**
 * SiteBackground:
 * Renders the barbershop wall photo (IMG_8851 - dark brick wall with scissors mural
 * and vertical neon/fluorescent lamp tube) as the atmospheric background across the entire site.
 *
 * Requirements fulfilled:
 * 1. Background of the whole site ("fundo do site todo").
 * 2. Controlled opacity so the authentic photograph, brick masonry, and scissors artwork
 *    are clearly visible without disappearing into pure black.
 * 3. The "luz/lâmpada" (light/lamp) is distinctly brighter and radiant, actively casting
 *    warm & white illumination across the site environment.
 * 4. Responsive positioning: on desktop the lamp is at ~60.7% (illuminating between text and 3D pole);
 *    on mobile it shifts gracefully to ~67% so typography has high contrast against the dark wall
 *    while the lamp illuminates the scene from the right.
 */
export const SiteBackground: React.FC = () => {
  return (
    <aside 
      aria-label="Cenário de fundo do estúdio"
      className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none"
    >
      {/* Studio dark base */}
      <div className="absolute inset-0 bg-[#09090c]" />

      {/* 
        LAYER 1: The real barbershop brick wall photograph (IMG_8851)
        Positioned at [67% 72%] on mobile and [60.7% 72%] on desktop.
        Brightness and contrast calibrated so brick masonry, mortar joints, and scissors artwork
        are distinctly perceptible across the entire site background.
      */}
      <div className="absolute inset-0">
        <img
          src="/assets/aistudio/IMG_8851_35fcdd32.jpeg"
          alt=""
          role="presentation"
          aria-hidden="true"
          className="w-full h-full object-cover object-[67%_72%] sm:object-[60.7%_72%] filter brightness-125 contrast-120 opacity-55"
        />
      </div>

      {/* 
        LAYER 2: The "Luz/Lâmpada" brighter isolation layer
        Uses an exact gradient mask focused on the lamp column,
        boosted with 2.2x brightness and contrast so the real incandescent lamp fixture
        glows powerfully above the wall.
      */}
      <div 
        className="absolute inset-0 overflow-hidden"
        style={{
          maskImage: 'linear-gradient(to right, transparent 46%, rgba(0,0,0,0.3) 53%, black 57%, black 65%, rgba(0,0,0,0.3) 69%, transparent 75%)',
          WebkitMaskImage: 'linear-gradient(to right, transparent 46%, rgba(0,0,0,0.3) 53%, black 57%, black 65%, rgba(0,0,0,0.3) 69%, transparent 75%)',
        }}
      >
        <img
          src="/assets/aistudio/IMG_8851_35fcdd32.jpeg"
          alt=""
          role="presentation"
          aria-hidden="true"
          className="w-full h-full object-cover object-[67%_72%] sm:object-[60.7%_72%] filter brightness-[2.2] contrast-[1.4] opacity-100 mix-blend-screen"
        />
      </div>

      {/* 
        LAYER 3: Active Environmental Illumination ("Iluminando o site")
        Simulates the lamp casting physical photons and luminous atmosphere.
      */}

      {/* 3A: Intense vertical white core along the lamp tube */}
      <div 
        className="absolute top-0 bottom-0 left-[67%] sm:left-[60.7%] -translate-x-1/2 w-2.5 sm:w-3.5 bg-gradient-to-b from-white via-white to-zinc-100 blur-[1px] opacity-95 shadow-[0_0_30px_10px_rgba(255,255,255,0.9),0_0_75px_28px_rgba(255,248,220,0.6),0_0_130px_55px_rgba(197,160,89,0.35)]"
        aria-hidden="true"
      />

      {/* 3B: Soft lateral diffusion halo radiating from the lamp column */}
      <div 
        className="absolute top-0 bottom-0 left-[67%] sm:left-[60.7%] -translate-x-1/2 w-32 sm:w-56 bg-gradient-to-r from-transparent via-white/30 to-transparent blur-2xl"
        aria-hidden="true"
      />

      {/* 3C: Wide ambient radial photon beam casting light over the site */}
      <div 
        className="absolute inset-0 bg-[radial-gradient(ellipse_1200px_900px_at_60.7%_45%,rgba(255,250,235,0.22),rgba(197,160,89,0.1)_42%,transparent_78%)]"
        aria-hidden="true"
      />

      {/* 3D: Warm electric ambient breathing glow */}
      <div 
        className="absolute top-0 bottom-0 left-[67%] sm:left-[60.7%] -translate-x-1/2 w-72 sm:w-[450px] bg-gradient-to-r from-transparent via-[#c5a059]/20 to-transparent blur-3xl animate-pulse"
        style={{ animationDuration: '4s' }}
        aria-hidden="true"
      />

      {/* 
        LAYER 4: Readability Vignettes (smooth, non-crushing)
        Provides gentle contrast for the left-side text column without hiding the photograph.
      */}
      {/* Subtle top & bottom edges */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#08080a]/60 via-transparent to-[#08080a]/75 pointer-events-none" />
      {/* Left reading protection: soft shadow under typography */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#08080a]/80 via-[#08080a]/40 to-transparent w-full md:w-3/5 pointer-events-none" />
      {/* Darkroom grain */}
      <div className="absolute inset-0 bg-grain opacity-20 pointer-events-none" />
    </aside>
  );
};
