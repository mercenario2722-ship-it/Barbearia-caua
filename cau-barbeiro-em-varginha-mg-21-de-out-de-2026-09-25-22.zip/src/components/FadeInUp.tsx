import React from 'react';
import { motion, useReducedMotion } from 'framer-motion';
import { getFadeInUpVariants } from '../utils/motionVariants.ts';

export interface FadeInUpProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  duration?: number;
  distance?: number;
  threshold?: number;
  margin?: string;
  immediate?: boolean;
}

/**
 * FadeInUp:
 * A subtle, elegant scroll entrance component using Framer Motion.
 * Smoothly fades and lifts content into view with custom luxury easing
 * and complete respects for reduced-motion accessibility preferences.
 */
export const FadeInUp: React.FC<FadeInUpProps> = ({
  children,
  className = '',
  delay = 0,
  duration = 0.7,
  distance = 28,
  threshold = 0.12,
  margin = '0px 0px -50px 0px',
  immediate = false,
}) => {
  const shouldReduceMotion = useReducedMotion();
  const variants = getFadeInUpVariants({
    distance,
    duration,
    delay,
    reducedMotion: !!shouldReduceMotion,
  });

  if (immediate) {
    return (
      <motion.div
        initial={variants.initial}
        animate={variants.animate}
        transition={variants.transition}
        className={className}
      >
        {children}
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={variants.initial}
      whileInView={variants.animate}
      viewport={{ once: true, amount: threshold, margin }}
      transition={variants.transition}
      className={className}
    >
      {children}
    </motion.div>
  );
};
