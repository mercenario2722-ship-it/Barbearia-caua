import React from 'react';
import { DIFFERENTIALS } from '../data/barbershop.ts';
import { Clock, Eye, Scissors, ShieldCheck, Sparkles, Users, Star, Award, CheckCircle } from 'lucide-react';
import { TiltCard } from './TiltCard.tsx';
import { AnimatedCounter } from './AnimatedCounter.tsx';
import { FadeInUp } from './FadeInUp.tsx';

const icons = [Clock, Eye, Scissors, ShieldCheck];

export const Diferenciais: React.FC = () => {
  return (
    <section id="diferenciais" className="py-28 bg-[#0a0a0d]/50 backdrop-blur-[1px] border-t border-zinc-900/80 relative scroll-mt-20 overflow-hidden">
      {/* Soft atmospheric radial glow integrated with global background */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div 
          className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[550px] h-[350px] bg-[#c5a059]/5 rounded-full blur-[140px]" 
          aria-hidden="true" 
        />
      </div>

      <FadeInUp>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900/80 border border-zinc-800 text-[#c5a059] text-xs font-semibold tracking-[0.2em] uppercase mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Padrão de Atendimento</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white text-balance leading-tight">
              Por que escolher o atendimento do Cauã?
            </h2>
          </div>
          <p className="text-zinc-300 text-sm sm:text-base max-w-md leading-relaxed">
            Uma abordagem contemporânea focada em respeito ao seu tempo, conforto no ambiente e resultado visual alinhado à sua personalidade.
          </p>
        </div>

        {/* 
          DESTAQUE DE CREDIBILIDADE SOCIAL:
          Contador animado de Clientes Satisfeitos com estética de números em destaque sobre fundo sutil
        */}
        <div className="mb-14">
          <TiltCard maxTilt={3} glare={true} scale={1.01}>
            <div className="p-8 sm:p-10 rounded-2xl bg-zinc-950/80 backdrop-blur-2xl border border-gold-glow shadow-[0_20px_50px_rgba(0,0,0,0.85)] relative overflow-hidden">
              {/* Subtle ambient light streak inside card */}
              <div 
                className="absolute top-0 right-1/4 w-96 h-96 bg-[#c5a059]/10 rounded-full blur-[120px] pointer-events-none" 
                aria-hidden="true" 
              />

              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center relative z-10">
                {/* Main Highlight: Clientes Satisfeitos Counter (6 cols) */}
                <div className="md:col-span-6 flex flex-col justify-center border-b md:border-b-0 md:border-r border-zinc-800/80 pb-6 md:pb-0 md:pr-8">
                  <div className="flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-[#c5a059] mb-3">
                    <Users className="w-4 h-4 text-[#c5a059]" />
                    <span>Autoridade & Confiança</span>
                  </div>

                  <div className="flex items-baseline gap-3">
                    <AnimatedCounter
                      target={1200}
                      prefix="+"
                      duration={2200}
                      className="font-heading text-5xl sm:text-6xl lg:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-[#fef0cd] via-[#c5a059] to-[#d4af37] tracking-tight drop-shadow-[0_4px_20px_rgba(197,160,89,0.25)]"
                    />
                    <span className="font-heading text-2xl sm:text-3xl font-bold text-white tracking-tight">
                      Clientes Satisfeitos
                    </span>
                  </div>

                  <p className="text-zinc-300 text-sm sm:text-base mt-3 leading-relaxed">
                    Cortes, barbas e alinhamentos finalizados com precisão cirúrgica e alto índice de fidelidade no Park Rinald.
                  </p>

                  <div className="flex items-center gap-2 mt-4 text-xs font-semibold text-zinc-400">
                    <div className="flex items-center text-[#c5a059]">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-[#c5a059]" />
                      ))}
                    </div>
                    <span className="text-zinc-200">5.0 / 5.0</span>
                    <span aria-hidden="true">·</span>
                    <span>Satisfação comprovada</span>
                  </div>
                </div>

                {/* Secondary Authority Metrics (6 cols) */}
                <div className="md:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-6 md:pl-4">
                  <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800/70">
                    <div className="flex items-center gap-2 text-zinc-400 text-xs font-medium uppercase tracking-wider mb-1">
                      <Clock className="w-3.5 h-3.5 text-[#c5a059]" />
                      <span>Pontualidade</span>
                    </div>
                    <div className="font-heading text-3xl font-extrabold text-white">
                      <AnimatedCounter target={100} suffix="%" duration={1800} />
                    </div>
                    <p className="text-zinc-400 text-xs mt-1">
                      Horário reservado com exclusividade, zero filas
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800/70">
                    <div className="flex items-center gap-2 text-zinc-400 text-xs font-medium uppercase tracking-wider mb-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-[#c5a059]" />
                      <span>Biossegurança</span>
                    </div>
                    <div className="font-heading text-3xl font-extrabold text-white">
                      <AnimatedCounter target={100} suffix="%" duration={1800} />
                    </div>
                    <p className="text-zinc-400 text-xs mt-1">
                      Lâminas descartáveis e ferramentas esterilizadas
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800/70">
                    <div className="flex items-center gap-2 text-zinc-400 text-xs font-medium uppercase tracking-wider mb-1">
                      <Scissors className="w-3.5 h-3.5 text-[#c5a059]" />
                      <span>Precisão</span>
                    </div>
                    <div className="font-heading text-3xl font-extrabold text-white">
                      Milimétrica
                    </div>
                    <p className="text-zinc-400 text-xs mt-1">
                      Degradê limpo sem marcas e visagismo facial
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800/70">
                    <div className="flex items-center gap-2 text-zinc-400 text-xs font-medium uppercase tracking-wider mb-1">
                      <Award className="w-3.5 h-3.5 text-[#c5a059]" />
                      <span>Localização</span>
                    </div>
                    <div className="font-heading text-2xl font-extrabold text-white">
                      Park Rinald
                    </div>
                    <p className="text-zinc-400 text-xs mt-1">
                      Varginha — MG com fácil estacionamento
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </TiltCard>
        </div>

        {/* 3D Tilt Cards with Frosted Glass & Gold Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {DIFFERENTIALS.map((item, index) => {
            const Icon = icons[index % icons.length];
            return (
              <TiltCard
                key={item.number}
                maxTilt={6}
                glare={true}
                scale={1.02}
                className="h-full"
              >
                <div className="h-full p-8 rounded-2xl bg-zinc-950/75 backdrop-blur-xl border border-zinc-800/80 hover:border-[#c5a059]/50 transition-all duration-300 flex flex-col justify-between shadow-[0_10px_30px_-10px_rgba(0,0,0,0.6)] group">
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <span className="font-heading text-3xl font-black text-zinc-500 group-hover:text-[#c5a059] transition-colors tabular-nums">
                        {item.number}
                      </span>
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-zinc-800/80 to-zinc-900 border border-zinc-700/60 flex items-center justify-center text-zinc-200 group-hover:text-[#c5a059] group-hover:border-[#c5a059]/40 transition-all shadow-md">
                        <Icon className="w-5 h-5" />
                      </div>
                    </div>

                    <h3 className="font-heading text-xl font-bold text-white mb-3 group-hover:text-zinc-100 transition-colors">
                      {item.title}
                    </h3>

                    <p className="text-zinc-400 text-sm leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  <div className="mt-8 pt-4 border-t border-zinc-800/60 flex items-center justify-between text-xs text-zinc-400 font-medium">
                    <span>Park Rinald · Varginha</span>
                    <span className="w-2 h-2 rounded-full bg-zinc-700 group-hover:bg-[#c5a059] group-hover:scale-125 transition-all" />
                  </div>
                </div>
              </TiltCard>
            );
          })}
        </div>
      </div>
      </FadeInUp>
    </section>
  );
};
