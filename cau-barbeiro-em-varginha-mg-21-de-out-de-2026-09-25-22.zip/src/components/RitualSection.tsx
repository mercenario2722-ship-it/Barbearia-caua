import React from 'react';
import { Coffee, Scissors, Sparkles, Wind, Eye } from 'lucide-react';
import { TiltCard } from './TiltCard.tsx';
import { FadeInUp } from './FadeInUp.tsx';

const STEPS = [
  {
    step: '01',
    title: 'A Análise & Visagismo',
    subtitle: 'Alinhamento antes da primeira tesourada',
    description:
      'Uma conversa rápida e franca olhando no espelho. Analisamos o formato do rosto, linha da nuca e caimento natural dos fios para escolher o corte que te valoriza todos os dias.',
    icon: Eye,
  },
  {
    step: '02',
    title: 'Degradê & Arquitetura',
    subtitle: 'Transição suave milimétrica',
    description:
      'Graduação limpa da pele ao topo usando máquinas profissionais e tesoura fio laser. O resultado é um corte que mantém a estrutura e continua bonito por semanas.',
    icon: Scissors,
  },
  {
    step: '03',
    title: 'O Ritual da Toalha Quente',
    subtitle: 'Relaxamento e navalha na barba',
    description:
      'Toalha quente vaporizada para amaciar os fios e abrir os poros. Lâmina 100% nova e descartável aberta na sua frente para um barbear sem irritações.',
    icon: Wind,
  },
  {
    step: '04',
    title: 'Finalização & Café',
    subtitle: 'Saia pronto para qualquer ocasião',
    description:
      'Lavagem rápida, pomada com acabamento matte natural de linha profissional e café passado na hora no ambiente reservado do Park Rinald.',
    icon: Coffee,
  },
];

export const RitualSection: React.FC = () => {
  return (
    <section id="ritual" className="py-28 bg-[#09090c]/50 backdrop-blur-[1px] border-t border-zinc-900/80 relative scroll-mt-20 overflow-hidden">
      {/* Ambient lighting accents */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div 
          className="absolute top-1/2 right-1/4 w-[500px] h-[400px] bg-[#c5a059]/5 rounded-full blur-[140px]" 
          aria-hidden="true" 
        />
      </div>

      <FadeInUp>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900/80 border border-zinc-800 text-[#c5a059] text-xs font-semibold tracking-[0.2em] uppercase mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>A Experiência na Prática</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
              O Ritual da Cadeira
            </h2>
          </div>
          <p className="text-zinc-300 text-sm sm:text-base max-w-md leading-relaxed">
            Aqui, cortar o cabelo e fazer a barba não é uma tarefa mecânica e corrida. É um momento de desacelerar, alinhar seu estilo e ser bem atendido.
          </p>
        </div>

        {/* 4 Steps Timeline Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {STEPS.map((item) => {
            const Icon = item.icon;
            return (
              <TiltCard key={item.step} maxTilt={5} glare={true} scale={1.02} className="h-full">
                <div className="h-full p-8 rounded-2xl bg-zinc-950/80 backdrop-blur-xl border border-zinc-800/80 hover:border-[#c5a059]/50 transition-all duration-300 flex flex-col justify-between shadow-[0_10px_30px_-10px_rgba(0,0,0,0.6)] group">
                  <div>
                    <div className="flex items-center justify-between mb-6">
                      <span className="font-heading text-3xl font-black text-zinc-500 group-hover:text-[#c5a059] transition-colors tabular-nums">
                        {item.step}
                      </span>
                      <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-zinc-800 to-zinc-900 border border-zinc-700/60 flex items-center justify-center text-zinc-200 group-hover:text-[#c5a059] group-hover:border-[#c5a059]/40 transition-all">
                        <Icon className="w-5 h-5" />
                      </div>
                    </div>

                    <h3 className="font-heading text-lg font-bold text-white mb-1 group-hover:text-zinc-100 transition-colors">
                      {item.title}
                    </h3>
                    <p className="text-[11px] font-semibold text-[#c5a059] uppercase tracking-wider mb-3">
                      {item.subtitle}
                    </p>

                    <p className="text-zinc-400 text-sm leading-relaxed">
                      {item.description}
                    </p>
                  </div>

                  <div className="mt-8 pt-4 border-t border-zinc-800/60 flex items-center justify-between text-xs text-zinc-400">
                    <span>Etapa {item.step}</span>
                    <span className="w-2 h-2 rounded-full bg-zinc-700 group-hover:bg-[#c5a059] transition-colors" />
                  </div>
                </div>
              </TiltCard>
            );
          })}
        </div>
      </div>
      </FadeInUp>
    </section>
  );
};
