import React from 'react';
import { CAUA_DISPLAY_PHONE, CAUA_LOCATION_NAME, buildWhatsAppLink, getBookingMessage } from '../utils/whatsapp.ts';
import { ArrowUp, MessageCircle, Scissors } from 'lucide-react';
import { FadeInUp } from './FadeInUp.tsx';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  const whatsappUrl = buildWhatsAppLink(getBookingMessage());

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050507]/80 backdrop-blur-md border-t border-zinc-900/90 text-zinc-400 py-16 relative overflow-hidden">
      <FadeInUp>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-zinc-800/60">
          {/* Brand & Identity (5 cols) */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-[#c5a059]/40 flex items-center justify-center text-[#c5a059] shadow-sm">
                <Scissors className="w-3.5 h-3.5 transform -rotate-45" />
              </div>
              <div className="flex flex-col">
                <span className="font-heading text-xl font-extrabold tracking-[0.18em] text-white">
                  CAUÃ
                </span>
                <span className="text-[9px] tracking-[0.3em] uppercase text-zinc-400 font-medium">
                  Barbearia · Park Rinald
                </span>
              </div>
            </div>

            <p className="text-sm text-zinc-400 max-w-sm leading-relaxed">
              Barbearia contemporânea e autoral. Atendimento personalizado com foco em degradê, corte masculino e alinhamento de barba.
            </p>

            <div className="text-xs text-zinc-400 pt-1 space-y-1 font-medium">
              <p className="text-zinc-300">{CAUA_LOCATION_NAME}</p>
              <p>Atendimentos com horário agendado</p>
            </div>
          </div>

          {/* Quick Navigation (3 cols) */}
          <div className="md:col-span-3 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-200 block mb-3 font-heading">
              Navegação
            </span>
            <ul className="space-y-2 text-sm font-medium">
              <li>
                <a href="#diferenciais" className="hover:text-[#c5a059] transition-colors">
                  Diferenciais
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-[#c5a059] transition-colors">
                  Serviços & Preços
                </a>
              </li>
              <li>
                <a href="#galeria" className="hover:text-[#c5a059] transition-colors">
                  Portfólio de Cortes
                </a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-[#c5a059] transition-colors">
                  Sobre o Cauã
                </a>
              </li>
              <li>
                <a href="#localizacao" className="hover:text-[#c5a059] transition-colors">
                  Localização no Park Rinald
                </a>
              </li>
            </ul>
          </div>

          {/* Direct Booking Column (4 cols) */}
          <div className="md:col-span-4 space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-200 block mb-3 font-heading">
              Agendamento Direto
            </span>
            <p className="text-sm text-zinc-400 leading-relaxed">
              Consulte os horários disponíveis e reserve seu atendimento diretamente pelo WhatsApp oficial.
            </p>
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2.5 px-5 py-3 text-xs font-bold uppercase tracking-wider text-zinc-950 bg-gradient-to-r from-[#e5c278] via-[#c5a059] to-[#b38e47] hover:brightness-110 active:scale-[0.98] rounded-sm transition-all shadow-md"
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              <span>{CAUA_DISPLAY_PHONE}</span>
            </a>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-400 font-medium">
          <p>
            &copy; {currentYear} Cauã — Barbeiro. Todos os direitos reservados. Park Rinald, Varginha - MG.
          </p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 hover:text-white transition-colors focus:outline-none"
            aria-label="Voltar ao topo da página"
          >
            <span>Voltar ao topo</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
      </FadeInUp>
    </footer>
  );
};
