import React, { useState } from 'react';
import { ChevronDown, HelpCircle, MessageCircle } from 'lucide-react';
import { buildWhatsAppLink } from '../utils/whatsapp.ts';
import { FadeInUp } from './FadeInUp.tsx';

interface FaqItem {
  question: string;
  answer: string;
}

const FAQS: FaqItem[] = [
  {
    question: 'Preciso agendar com antecedência?',
    answer:
      'Sim! Para garantir que você não enfrente nenhuma fila e seja atendido com calma no seu horário exato, os atendimentos no Park Rinald são realizados estritamente com hora marcada.',
  },
  {
    question: 'Nunca cortei com o Cauã. Posso levar foto de referência?',
    answer:
      'Com certeza! Pode mandar a referência pelo WhatsApp antes ou mostrar no celular ao sentar na cadeira. O Cauã vai avaliar a foto e adaptá-la para o formato do seu rosto e o caimento natural dos seus fios.',
  },
  {
    question: 'Quais as formas de pagamento aceitas?',
    answer:
      'Aceitamos Pix, cartão de crédito e débito, além de dinheiro físico. O acerto é feito presencialmente após o término do corte.',
  },
  {
    question: 'Como é o estacionamento no Park Rinald?',
    answer:
      'O bairro Park Rinald é residencial, muito tranquilo e seguro. Há bastante espaço na rua para estacionar carro ou moto sem custo nem estresse de centro da cidade.',
  },
  {
    question: 'Quanto tempo dura o corte e a barba?',
    answer:
      'O corte masculino ou degradê dura em média 45 minutos. O combo completo de cabelo e barba leva cerca de 1 hora e 15 minutos, incluindo o relaxamento com toalha quente e alinhamento na navalha.',
  },
];

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIndex((prev) => (prev === idx ? null : idx));
  };

  const whatsappDuvidasUrl = buildWhatsAppLink(
    'Olá, Cauã! Tenho uma dúvida sobre os horários e atendimentos no Park Rinald antes de agendar.'
  );

  return (
    <section id="faq" className="py-24 bg-[#0a0a0d]/50 backdrop-blur-[1px] border-t border-zinc-900/80 relative scroll-mt-20 overflow-hidden">
      <FadeInUp>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900/80 border border-zinc-800 text-[#c5a059] text-xs font-semibold tracking-[0.2em] uppercase mb-4">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Tire suas Dúvidas</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
            Perguntas Frequentes
          </h2>
          <p className="text-zinc-400 text-sm mt-2 max-w-lg mx-auto">
            Informações práticas e transparentes sobre o atendimento no Park Rinald em Varginha.
          </p>
        </div>

        {/* Accordion list */}
        <div className="space-y-3.5">
          {FAQS.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className="rounded-2xl bg-zinc-950/70 border border-zinc-800/80 overflow-hidden transition-all duration-200"
              >
                <button
                  type="button"
                  onClick={() => toggle(index)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 focus:outline-none focus-visible:ring-1 focus-visible:ring-[#c5a059]"
                  aria-expanded={isOpen}
                >
                  <span className="font-heading text-base sm:text-lg font-bold text-white">
                    {faq.question}
                  </span>
                  <div
                    className={`w-7 h-7 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-300 transition-transform duration-200 shrink-0 ${
                      isOpen ? 'rotate-180 text-[#c5a059] border-[#c5a059]/40' : ''
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-6 text-sm text-zinc-300 leading-relaxed border-t border-zinc-900/80 pt-3">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Still have questions card */}
        <div className="mt-10 p-6 rounded-2xl bg-gradient-to-r from-zinc-950 to-zinc-900 border border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <p className="text-sm font-bold text-white">Ainda tem alguma dúvida?</p>
            <p className="text-xs text-zinc-400 mt-0.5">Fale diretamente com o Cauã pelo WhatsApp.</p>
          </div>
          <a
            href={whatsappDuvidasUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-sm bg-[#c5a059] hover:bg-[#d4af37] text-zinc-950 text-xs font-bold uppercase tracking-wider transition-colors shrink-0"
          >
            <MessageCircle className="w-4 h-4 fill-current" />
            <span>Chamar no WhatsApp</span>
          </a>
        </div>
      </div>
      </FadeInUp>
    </section>
  );
};
