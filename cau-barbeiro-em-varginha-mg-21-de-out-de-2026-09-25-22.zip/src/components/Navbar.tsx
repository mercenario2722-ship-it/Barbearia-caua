import React, { useState, useEffect } from 'react';
import { Menu, X, ArrowUpRight, Scissors } from 'lucide-react';
import { buildWhatsAppLink, getBookingMessage } from '../utils/whatsapp.ts';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'Diferenciais', href: '#diferenciais' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Cortes', href: '#galeria' },
    { label: 'Sobre', href: '#sobre' },
    { label: 'Localização', href: '#localizacao' },
  ];

  const handleLinkClick = () => {
    setMobileMenuOpen(false);
  };

  const whatsappUrl = buildWhatsAppLink(getBookingMessage());

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#08080a]/90 backdrop-blur-xl border-b border-zinc-800/80 shadow-[0_10px_30px_-10px_rgba(0,0,0,0.8)] py-3.5'
          : 'bg-gradient-to-b from-[#08080a]/80 via-[#08080a]/30 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8">
          {/* Zone 1: Distinctive bespoke brand mark */}
          <a
            href="#"
            className="group flex items-center gap-3 whitespace-nowrap shrink-0 focus:outline-none"
            aria-label="Cauã Barbeiro - Início"
          >
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-[#d4af37]/20 via-zinc-900 to-black border border-[#c5a059]/40 flex items-center justify-center text-[#c5a059] group-hover:scale-105 group-hover:border-[#c5a059] transition-all shadow-md">
              <Scissors className="w-4 h-4 transform -rotate-45" />
            </div>
            <div className="flex flex-col">
              <span className="font-heading text-xl font-extrabold tracking-[0.18em] text-white transition-colors group-hover:text-[#c5a059]">
                CAUÃ
              </span>
              <span className="text-[9px] tracking-[0.3em] uppercase text-zinc-400 font-medium">
                Barbearia · Park Rinald
              </span>
            </div>
          </a>

          {/* Zone 2: 4-5 clean single-line nav links with hover indicator */}
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-300">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="whitespace-nowrap shrink-0 hover:text-[#c5a059] transition-colors relative py-1 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#c5a059] group"
              >
                <span>{link.label}</span>
                <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-gradient-to-r from-[#c5a059] to-transparent group-hover:w-full transition-all duration-300" />
              </a>
            ))}
          </nav>

          {/* Zone 3: 1 primary action button with 3D tactile feel */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="relative inline-flex items-center gap-2.5 px-5 py-2.5 text-xs font-bold tracking-wider uppercase text-zinc-950 bg-gradient-to-r from-[#e5c278] via-[#c5a059] to-[#b38e47] hover:brightness-110 active:scale-[0.98] rounded-sm transition-all duration-200 shadow-[0_4px_20px_rgba(197,160,89,0.25)] hover:shadow-[0_6px_25px_rgba(197,160,89,0.4)] whitespace-nowrap shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#c5a059]"
            >
              <span>Agendar Horário</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Mobile hamburger button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 text-xs font-bold uppercase text-zinc-950 bg-gradient-to-r from-[#e5c278] to-[#c5a059] rounded-sm sm:hidden shadow-sm"
            >
              Agendar
            </a>
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-zinc-300 hover:text-white rounded-md bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700 focus:outline-none focus:ring-1 focus:ring-[#c5a059]"
              aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0c0c0f]/95 backdrop-blur-2xl border-b border-zinc-800/90 px-6 py-6 mt-3 space-y-4 shadow-2xl animate-in slide-in-from-top-3 duration-200">
          <div className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={handleLinkClick}
                className="text-base font-medium text-zinc-200 hover:text-[#c5a059] py-2 border-b border-zinc-800/40"
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="pt-2">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={handleLinkClick}
              className="w-full flex items-center justify-center gap-2 py-3.5 text-xs font-bold tracking-wider uppercase text-zinc-950 bg-gradient-to-r from-[#e5c278] via-[#c5a059] to-[#b38e47] rounded-sm shadow-lg"
            >
              <span>Agendar Horário no WhatsApp</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
            <p className="text-center text-xs text-zinc-400 mt-3 font-medium">
              Park Rinald · Varginha — MG
            </p>
          </div>
        </div>
      )}
    </header>
  );
};
