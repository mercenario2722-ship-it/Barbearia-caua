import React, { useState } from 'react';
import { MapPin, Navigation, Copy, Check, MessageSquare, Sparkles } from 'lucide-react';
import { CAUA_LOCATION_NAME, CAUA_LOCATION_MAPS_URL, buildWhatsAppLink } from '../utils/whatsapp.ts';
import { TiltCard } from './TiltCard.tsx';
import { FadeInUp } from './FadeInUp.tsx';

export const Location: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(CAUA_LOCATION_NAME);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const whatsappDirectionsUrl = buildWhatsAppLink(
    'Olá, Cauã! Gostaria de confirmar o ponto de referência exato para chegar ao Park Rinald em Varginha.'
  );

  return (
    <section id="localizacao" className="py-28 bg-[#08080a]/50 backdrop-blur-[1px] border-t border-zinc-900/80 relative scroll-mt-20 overflow-hidden">
      {/* Ambient lighting accents */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div 
          className="absolute top-1/2 left-1/3 w-[500px] h-[400px] bg-[#c5a059]/5 rounded-full blur-[140px]" 
          aria-hidden="true" 
        />
      </div>

      <FadeInUp>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          {/* Info Card (6 cols) */}
          <div className="lg:col-span-6 p-8 sm:p-10 rounded-2xl bg-zinc-950/85 backdrop-blur-2xl border border-zinc-700/80 flex flex-col justify-between shadow-[0_20px_50px_rgba(0,0,0,0.85)]">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900/80 border border-zinc-800 text-[#c5a059] text-xs font-semibold tracking-[0.2em] uppercase mb-4">
                <MapPin className="w-3.5 h-3.5 text-[#c5a059]" />
                <span>Onde Encontrar</span>
              </div>

              <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white mb-4">
                Localização & Atendimento
              </h2>

              <p className="text-zinc-300 text-sm sm:text-base leading-relaxed mb-8">
                O atendimento do Cauã fica no bairro <strong className="text-white font-bold">Park Rinald</strong>, em Varginha — MG. Um ambiente discreto e bem localizado para você relaxar enquanto renova o visual.
              </p>

              {/* Address details card */}
              <div className="p-5 rounded-xl bg-zinc-900/90 border border-zinc-800/90 space-y-3 mb-6 shadow-inner">
                <div className="flex items-center justify-between text-xs text-zinc-400 font-medium">
                  <span className="uppercase tracking-wider">Bairro & Cidade</span>
                  <span className="text-[#c5a059] font-bold">Varginha — MG</span>
                </div>
                <p className="font-heading text-lg font-bold text-white">
                  {CAUA_LOCATION_NAME}
                </p>
                <p className="text-xs text-zinc-400">
                  (Endereço detalhado e ponto de referência enviados na confirmação do agendamento)
                </p>
              </div>

              {/* Practical points */}
              <div className="grid grid-cols-2 gap-4 text-xs text-zinc-300 pt-2">
                <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800/70">
                  <span className="text-[#c5a059] font-bold block mb-0.5">Estacionamento</span>
                  <span>Fácil estacionamento no local</span>
                </div>
                <div className="p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800/70">
                  <span className="text-[#c5a059] font-bold block mb-0.5">Acesso</span>
                  <span>Bairro tranquilo e seguro</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-8 border-t border-zinc-800/80 flex flex-col sm:flex-row items-stretch sm:items-center gap-3 mt-8">
              <a
                href={CAUA_LOCATION_MAPS_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs font-bold uppercase tracking-wider text-zinc-950 bg-gradient-to-r from-[#e5c278] via-[#c5a059] to-[#b38e47] hover:brightness-110 active:scale-[0.98] rounded-sm transition-all shadow-md focus:outline-none focus:ring-2 focus:ring-[#c5a059]"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Abrir no Google Maps</span>
              </a>

              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center justify-center gap-2 px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-zinc-300 hover:text-white bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/80 rounded-sm transition-colors focus:outline-none focus:ring-1 focus:ring-zinc-400 shadow-sm"
                aria-live="polite"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar Localização</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Interactive Visual Map & Atmosphere Preview with 3D Tilt (6 cols) */}
          <div className="lg:col-span-6 flex flex-col">
            <TiltCard maxTilt={5} glare={true} scale={1.02} className="h-full">
              <div className="h-full rounded-2xl overflow-hidden border border-zinc-700/80 bg-zinc-950/80 backdrop-blur-xl flex flex-col justify-between shadow-[0_20px_50px_rgba(0,0,0,0.85)] group">
                {/* Visual Ambiance Image: IMG_8858 - Scissors wall & vertical light bar */}
                <div className="relative h-64 sm:h-72 overflow-hidden bg-zinc-900">
                  <img
                    src="/assets/aistudio/IMG_8858_391f3982.jpeg"
                    alt="Espaço da barbearia do Cauã no Park Rinald"
                    className="w-full h-full object-cover filter contrast-110 brightness-90 group-hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  <div 
                    className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/30 to-transparent" 
                    aria-hidden="true" 
                  />
                  <div className="absolute top-4 left-4 bg-zinc-950/85 backdrop-blur-md px-3 py-1.5 rounded text-[11px] font-bold text-zinc-200 border border-zinc-700/80 flex items-center gap-1.5">
                    <Sparkles className="w-3 h-3 text-[#c5a059]" />
                    <span>Park Rinald, Varginha</span>
                  </div>
                </div>

                {/* Practical Navigation Guidance */}
                <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                  <div className="space-y-4">
                    <h3 className="font-heading text-xl font-bold text-white">
                      Como funciona o atendimento no Park Rinald?
                    </h3>
                    <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed font-normal">
                      Para proporcionar total privacidade e dedicação, os atendimentos são realizados estritamente com horário marcado. Ao confirmar pelo WhatsApp, você receberá a rota direta e todas as instruções de chegada.
                    </p>
                  </div>

                  <div className="pt-6 border-t border-zinc-800/80 flex items-center justify-between text-xs text-zinc-400 mt-6 font-medium">
                    <span>Dúvida sobre o trajeto?</span>
                    <a
                      href={whatsappDirectionsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-[#c5a059] hover:text-[#e5c278] font-bold"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Perguntar no WhatsApp</span>
                    </a>
                  </div>
                </div>
              </div>
            </TiltCard>
          </div>
        </div>
      </div>
      </FadeInUp>
    </section>
  );
};
