import React from 'react';
import { ArrowDown, MessageCircle, MapPin, Sparkles, CheckCircle2 } from 'lucide-react';
import { buildWhatsAppLink, getBookingMessage } from '../utils/whatsapp.ts';
import { BarberPole3D } from './BarberPole3D.tsx';
import { FadeInUp } from './FadeInUp.tsx';

export const Hero: React.FC = () => {
  const whatsappUrl = buildWhatsAppLink(getBookingMessage());

  return (
    <section className="relative min-h-[94vh] flex items-center pt-32 pb-20 overflow-hidden bg-transparent">
      {/* Subtle atmospheric accents integrated with the whole-site background */}
      <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none">
        {/* Soft radial glow behind 3D pole and hero text */}
        <div 
          className="absolute -top-32 right-1/4 w-[500px] h-[500px] bg-[#c5a059]/10 rounded-full blur-[150px]" 
          aria-hidden="true" 
        />
        <div 
          className="absolute bottom-10 left-10 w-[400px] h-[400px] bg-zinc-700/10 rounded-full blur-[120px]" 
          aria-hidden="true" 
        />
      </div>

      <FadeInUp immediate duration={0.8} distance={24} className="w-full">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          {/* Left Column: Typography & CTAs (7 cols) */}
          <div className="lg:col-span-7 flex flex-col items-start space-y-6 sm:space-y-8">
            {/* Location Kicker */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-zinc-900/80 backdrop-blur-md border border-zinc-700/60 text-[#c5a059] text-xs font-semibold tracking-[0.2em] uppercase shadow-inner">
              <MapPin className="w-3.5 h-3.5 text-[#c5a059]" />
              <span>Park Rinald, Varginha — MG</span>
            </div>

            {/* Main Headline with Sora typography */}
            <div className="space-y-2">
              <h1 className="font-heading text-4xl sm:text-5xl md:text-6xl xl:text-7xl font-extrabold tracking-tight text-white leading-[1.08] text-balance">
                Seu estilo.{' '}
                <span className="block text-zinc-300 font-bold">Seu corte.</span>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#f7e0a3] via-[#c5a059] to-[#9e7c38] drop-shadow-[0_4px_16px_rgba(197,160,89,0.3)]">
                  Sua identidade.
                </span>
              </h1>
            </div>

            {/* Supporting paragraph */}
            <p className="text-base sm:text-lg text-zinc-200 max-w-xl font-normal leading-relaxed text-pretty drop-shadow-[0_2px_10px_rgba(0,0,0,0.9)]">
              Um corte bem feito vai além do visual. É sobre encontrar o estilo que combina com você,
              com atendimento exclusivo, hora marcada e atenção artesanal a cada detalhe.
            </p>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto pt-2">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group relative inline-flex items-center justify-center gap-3 px-8 py-4 text-xs sm:text-sm font-bold tracking-wider uppercase text-zinc-950 bg-gradient-to-r from-[#e5c278] via-[#c5a059] to-[#b38e47] hover:brightness-110 active:scale-[0.98] rounded-sm transition-all duration-200 shadow-[0_8px_30px_rgba(197,160,89,0.3)] hover:shadow-[0_10px_40px_rgba(197,160,89,0.45)] hover:-translate-y-0.5 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#c5a059]"
              >
                <MessageCircle className="w-4 h-4 fill-current group-hover:scale-110 transition-transform" />
                <span>Agendar meu horário</span>
              </a>

              <a
                href="#galeria"
                className="inline-flex items-center justify-center gap-2 px-7 py-4 text-xs sm:text-sm font-semibold tracking-wider uppercase text-zinc-200 hover:text-white bg-zinc-900/80 hover:bg-zinc-800/90 border border-zinc-700/80 hover:border-zinc-500 rounded-sm transition-all duration-200 backdrop-blur-md shadow-md focus:outline-none focus-visible:ring-1 focus-visible:ring-zinc-400"
              >
                <span>Ver cortes</span>
                <ArrowDown className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* 3D Glass Trust Badges Strip */}
            <div className="pt-6 border-t border-zinc-800/80 w-full grid grid-cols-3 gap-3 sm:gap-4 text-left">
              <div className="p-3 rounded-lg bg-zinc-950/60 backdrop-blur-md border border-zinc-800/80">
                <p className="text-[10px] uppercase tracking-wider text-[#c5a059] font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Horário</span>
                </p>
                <p className="text-xs sm:text-sm font-bold text-white mt-1">Com hora marcada</p>
              </div>

              <div className="p-3 rounded-lg bg-zinc-950/60 backdrop-blur-md border border-zinc-800/80">
                <p className="text-[10px] uppercase tracking-wider text-[#c5a059] font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Técnica</span>
                </p>
                <p className="text-xs sm:text-sm font-bold text-white mt-1">Degradê & Tesoura</p>
              </div>

              <div className="p-3 rounded-lg bg-zinc-950/60 backdrop-blur-md border border-zinc-800/80">
                <p className="text-[10px] uppercase tracking-wider text-[#c5a059] font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>Ambiente</span>
                </p>
                <p className="text-xs sm:text-sm font-bold text-white mt-1">Exclusivo Park Rinald</p>
              </div>
            </div>
          </div>

          {/* Right Column: 3D Rotating Barber Pole (approx 42% width) */}
          <div className="lg:col-span-5 relative w-full flex flex-col items-center justify-center">
            <div className="relative w-full max-w-[460px] flex items-center justify-center">
              {/* 3D Barber Pole Canvas with transparent background and continuous Y-rotation */}
              <BarberPole3D className="w-full" />
            </div>

            {/* Micro details bar below 3D model */}
            <div className="mt-2 w-full max-w-[420px] px-4 py-2.5 rounded-xl bg-zinc-950/70 backdrop-blur-md border border-zinc-800/80 flex items-center justify-between text-xs text-zinc-400 shadow-xl">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#c5a059] animate-pulse" />
                <span className="font-semibold text-zinc-200">Símbolo Tradicional</span>
              </div>
              <span className="font-mono text-[11px] text-[#c5a059]">Park Rinald • Varginha</span>
            </div>
          </div>
        </div>
      </div>
      </FadeInUp>
    </section>
  );
};
