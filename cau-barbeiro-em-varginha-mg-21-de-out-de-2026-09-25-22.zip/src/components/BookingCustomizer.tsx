import React, { useState } from 'react';
import { SERVICES } from '../data/barbershop.ts';
import { formatPrice, formatDuration, buildWhatsAppLink, buildCustomBookingMessage } from '../utils/whatsapp.ts';
import { MessageCircle, Check, Clock, Calendar, Sparkles } from 'lucide-react';
import { TiltCard } from './TiltCard.tsx';

export const BookingCustomizer: React.FC = () => {
  const [selectedServiceIds, setSelectedServiceIds] = useState<string[]>(['corte-fade', 'barba-alinhamento']);
  const [selectedPeriod, setSelectedPeriod] = useState<'manha' | 'tarde' | 'noite' | 'qualquer'>('tarde');

  const toggleService = (id: string) => {
    setSelectedServiceIds((prev) => {
      if (prev.includes(id)) {
        if (prev.length === 1) return prev; // Keep at least one selected
        return prev.filter((sId) => sId !== id);
      }
      return [...prev, id];
    });
  };

  const selectedServices = SERVICES.filter((s) => selectedServiceIds.includes(s.id));
  
  const totalPrice = selectedServices.reduce((sum, s) => {
    return sum + (typeof s.price === 'number' ? s.price : 0);
  }, 0);

  const totalDuration = selectedServices.reduce((sum, s) => {
    return sum + (s.durationMinutes || 0);
  }, 0);

  const whatsappMessage = buildCustomBookingMessage({
    serviceNames: selectedServices.map((s) => s.name),
    totalPrice,
    totalDurationMinutes: totalDuration,
    periodPreference: selectedPeriod,
  });

  const whatsappUrl = buildWhatsAppLink(whatsappMessage);

  return (
    <div className="mt-16 relative">
      <TiltCard maxTilt={3} glare={true} scale={1.01}>
        <div className="p-8 sm:p-10 rounded-3xl bg-zinc-950/90 backdrop-blur-2xl border border-gold-glow shadow-[0_25px_60px_rgba(0,0,0,0.85)] relative overflow-hidden">
          {/* Subtle amber ambient spotlight */}
          <div 
            className="absolute -top-20 -left-20 w-80 h-80 bg-[#c5a059]/10 rounded-full blur-[100px] pointer-events-none" 
            aria-hidden="true" 
          />

          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8 pb-8 border-b border-zinc-800/80">
            <div>
              <div className="inline-flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-[#c5a059] mb-2">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Simulador de Atendimento</span>
              </div>
              <h3 className="font-heading text-2xl sm:text-3xl font-extrabold text-white">
                Monte seu combo para esta semana
              </h3>
              <p className="text-zinc-400 text-sm mt-1 max-w-xl">
                Selecione os procedimentos que deseja realizar. O valor e o tempo estimado são calculados na hora e enviados prontos para o Cauã no WhatsApp.
              </p>
            </div>

            {/* Total summary badge */}
            <div className="flex items-center gap-6 p-4 rounded-2xl bg-zinc-900/80 border border-zinc-800 shrink-0">
              <div>
                <span className="text-[10px] uppercase tracking-wider text-zinc-400 block font-bold">
                  Previsão Total
                </span>
                <span className="font-heading text-2xl sm:text-3xl font-black text-white tabular-nums">
                  {formatPrice(totalPrice)}
                </span>
              </div>
              <div className="h-10 w-[1px] bg-zinc-800" />
              <div>
                <span className="text-[10px] uppercase tracking-wider text-zinc-400 block font-bold flex items-center gap-1">
                  <Clock className="w-3 h-3 text-[#c5a059]" />
                  <span>Duração</span>
                </span>
                <span className="font-heading text-lg font-bold text-zinc-200 tabular-nums">
                  ~{formatDuration(totalDuration)}
                </span>
              </div>
            </div>
          </div>

          {/* Interactive Selection Grid */}
          <div className="py-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {SERVICES.map((service) => {
              const isSelected = selectedServiceIds.includes(service.id);
              return (
                <button
                  key={service.id}
                  type="button"
                  onClick={() => toggleService(service.id)}
                  className={`p-4 rounded-xl border text-left transition-all duration-200 flex items-start justify-between gap-3 focus:outline-none focus:ring-1 focus:ring-[#c5a059] ${
                    isSelected
                      ? 'bg-gradient-to-br from-[#c5a059]/15 to-zinc-900 border-[#c5a059]/60 shadow-[0_4px_20px_rgba(197,160,89,0.12)]'
                      : 'bg-zinc-900/40 hover:bg-zinc-900/80 border-zinc-800/80 hover:border-zinc-700'
                  }`}
                  aria-pressed={isSelected}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-heading text-sm font-bold text-white">
                        {service.name}
                      </span>
                    </div>
                    <span className="text-xs text-zinc-400 block mt-0.5">
                      {formatDuration(service.durationMinutes)}
                    </span>
                  </div>

                  <div className="flex flex-col items-end">
                    <span className="font-heading text-sm font-bold text-[#c5a059] tabular-nums">
                      {formatPrice(service.price)}
                    </span>
                    <div
                      className={`w-5 h-5 rounded-md mt-1 flex items-center justify-center transition-colors ${
                        isSelected
                          ? 'bg-[#c5a059] text-zinc-950'
                          : 'bg-zinc-800 border border-zinc-700 text-transparent'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Shift Preference & WhatsApp Action */}
          <div className="pt-6 border-t border-zinc-800/80 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="flex flex-col sm:flex-row sm:items-center gap-3">
              <span className="text-xs text-zinc-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#c5a059]" />
                <span>Preferência:</span>
              </span>
              <div className="flex flex-wrap items-center gap-1.5">
                {[
                  { id: 'manha', label: 'Manhã' },
                  { id: 'tarde', label: 'Tarde' },
                  { id: 'noite', label: 'Final de tarde' },
                  { id: 'qualquer', label: 'Qualquer' },
                ].map((period) => (
                  <button
                    key={period.id}
                    type="button"
                    onClick={() => setSelectedPeriod(period.id as any)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      selectedPeriod === period.id
                        ? 'bg-[#c5a059] text-zinc-950 font-bold shadow-sm'
                        : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
                    }`}
                  >
                    {period.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-xs font-bold tracking-wider uppercase text-zinc-950 bg-gradient-to-r from-[#e5c278] via-[#c5a059] to-[#b38e47] hover:brightness-110 active:scale-[0.98] rounded-sm transition-all shadow-[0_6px_25px_rgba(197,160,89,0.35)] focus:outline-none focus:ring-2 focus:ring-[#c5a059]"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                <span>Confirmar vaga no WhatsApp</span>
              </a>
            </div>
          </div>

          <p className="text-[11px] text-zinc-500 mt-4 text-center sm:text-left">
            * Sem cobrança pelo site. O pagamento é realizado diretamente com o Cauã no Park Rinald no Pix ou cartão.
          </p>
        </div>
      </TiltCard>
    </div>
  );
};
