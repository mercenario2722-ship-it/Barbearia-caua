import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { RotateCw } from 'lucide-react';

interface BarberPole3DProps {
  className?: string;
}

export const BarberPole3D: React.FC<BarberPole3DProps> = ({ className = '' }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [isInteracting, setIsInteracting] = useState(false);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let isDisposed = false;
    let animFrameId: number = 0;
    let pollTimerId: number = 0;

    // Detect software WebGL (SwiftShader, llvmpipe)
    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return false;
      }
    })();

    // 1. Scene setup
    const scene = new THREE.Scene();
    scene.background = null; // 100% transparent canvas

    const width = container.clientWidth || 360;
    const height = container.clientHeight || 460;

    // 2. Camera setup with vertical clearance
    const camera = new THREE.PerspectiveCamera(34, width / height, 0.1, 100);
    camera.position.set(0, 0.05, 4.6);

    // 3. Renderer setup
    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.setClearColor(0x000000, 0); // Transparent clear
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';

    container.appendChild(renderer.domElement);

    // 4. Studio Environment reflections for metals & glass
    try {
      const pmremGenerator = new THREE.PMREMGenerator(renderer);
      scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
      pmremGenerator.dispose();
    } catch (e) {
      console.warn('RoomEnvironment fallback', e);
    }

    // 5. Studio Lighting Rig
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.5);
    scene.add(ambientLight);

    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x444444, 0.9);
    hemiLight.position.set(0, 8, 0);
    scene.add(hemiLight);

    // Key Light (Warm golden highlight)
    const keyLight = new THREE.DirectionalLight(0xfff5e4, 2.6);
    keyLight.position.set(3, 4, 3);
    scene.add(keyLight);

    // Fill Light (Cool blue fill)
    const fillLight = new THREE.DirectionalLight(0xdbeafe, 1.6);
    fillLight.position.set(-3, 2, 2);
    scene.add(fillLight);

    // Rim/Backlight (Highlights the glass contours)
    const rimLight = new THREE.DirectionalLight(0xffffff, 1.8);
    rimLight.position.set(0, 3, -3);
    scene.add(rimLight);

    // Internal Cylinder Light (illuminates the stripes like a real lit barber pole!)
    const internalLight = new THREE.PointLight(0xffffff, 2.2, 4.0);
    internalLight.position.set(0, 0, 0.2);
    scene.add(internalLight);

    // 6. Ground contact shadow
    const shadowCanvas = document.createElement('canvas');
    shadowCanvas.width = 128;
    shadowCanvas.height = 128;
    const shadowCtx = shadowCanvas.getContext('2d');
    if (shadowCtx) {
      const grad = shadowCtx.createRadialGradient(64, 64, 0, 64, 64, 60);
      grad.addColorStop(0, 'rgba(0, 0, 0, 0.55)');
      grad.addColorStop(0.4, 'rgba(0, 0, 0, 0.25)');
      grad.addColorStop(0.8, 'rgba(0, 0, 0, 0.04)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      shadowCtx.fillStyle = grad;
      shadowCtx.fillRect(0, 0, 128, 128);
    }
    const shadowTexture = new THREE.CanvasTexture(shadowCanvas);
    const shadowGeo = new THREE.PlaneGeometry(1.9, 1.9);
    const shadowMat = new THREE.MeshBasicMaterial({
      map: shadowTexture,
      transparent: true,
      opacity: 0.38,
      depthWrite: false,
    });
    const contactShadow = new THREE.Mesh(shadowGeo, shadowMat);
    contactShadow.rotation.x = -Math.PI / 2;
    contactShadow.position.y = -1.4;
    scene.add(contactShadow);

    // 7. Model container group
    const modelGroup = new THREE.Group();
    // Initial angle showing front stripes clearly
    modelGroup.rotation.y = 0.25;
    scene.add(modelGroup);

    let innerStripesNode: THREE.Object3D | null = null;

    // 8. GLTF Loader
    const loader = new GLTFLoader();
    const primaryUrl = '/barber-pole.glb';
    const fallbackUrl = '/models/barber-pole/scene.gltf';

    const loadModel = (url: string) => {
      loader.load(
        url,
        (gltf) => {
          if (isDisposed) return;

          const root = gltf.scene;

          // Material and mesh enhancement
          root.traverse((child) => {
            if ((child as THREE.Mesh).isMesh) {
              const mesh = child as THREE.Mesh;
              mesh.castShadow = !isSoftwareGl;
              mesh.receiveShadow = !isSoftwareGl;

              const lowerName = child.name.toLowerCase();

              // 1. Inner stripes cylinder -> RENDER ORDER 1 (Draws first!)
              if (lowerName.includes('inner')) {
                mesh.renderOrder = 1;
                const mat = mesh.material as THREE.MeshStandardMaterial;
                mat.transparent = false;
                mat.depthWrite = true;
                mat.color = new THREE.Color(0xffffff);
                mat.roughness = 0.3;
                mat.metalness = 0.0;
                mat.emissive = new THREE.Color(0x222222);
                mat.emissiveIntensity = 0.2;
                if (mat.map) {
                  mat.map.colorSpace = THREE.SRGBColorSpace;
                  mat.map.needsUpdate = true;
                }
                mat.needsUpdate = true;
              }

              // 2. Outer glass cylinder -> RENDER ORDER 20 (Draws AFTER inner cylinder!)
              else if (lowerName.includes('glass')) {
                mesh.renderOrder = 20;
                // Pure crystal clear glass with depthWrite=false
                mesh.material = new THREE.MeshPhysicalMaterial({
                  color: new THREE.Color(0xffffff),
                  transparent: true,
                  opacity: 0.22,
                  roughness: 0.05,
                  metalness: 0.08,
                  depthWrite: false,
                });
              }

              // 3. Polished brass/gold metal casing
              else if (lowerName.includes('metal')) {
                mesh.renderOrder = 5;
                mesh.material = new THREE.MeshStandardMaterial({
                  color: new THREE.Color(0xd4af37),
                  metalness: 0.92,
                  roughness: 0.18,
                });
              }

              // 4. Glowing opalescent lamp on top
              else if (lowerName.includes('light')) {
                mesh.renderOrder = 6;
                mesh.material = new THREE.MeshStandardMaterial({
                  color: new THREE.Color(0xfffcf0),
                  emissive: new THREE.Color(0xfff7e2),
                  emissiveIntensity: 0.95,
                  roughness: 0.15,
                  metalness: 0.0,
                });
              }
            }

            // Identify inner stripes node
            if (child.name.toLowerCase().includes('inner') && !innerStripesNode) {
              innerStripesNode = child;
            }
          });

          // Compute bounding box and center perfectly
          const box = new THREE.Box3().setFromObject(root);
          const center = box.getCenter(new THREE.Vector3());
          const size = box.getSize(new THREE.Vector3());

          // Recenter geometry inside modelGroup
          root.position.x = -center.x;
          root.position.y = -center.y;
          root.position.z = -center.z;

          // Scale so entire pole has breathing room
          const maxDim = Math.max(size.x, size.y, size.z);
          const targetHeight = 2.35;
          const scale = targetHeight / (maxDim || 1);
          modelGroup.scale.setScalar(scale);

          // Position group vertically centered
          modelGroup.position.y = 0.0;

          modelGroup.add(root);
          setIsLoading(false);
        },
        undefined,
        (error) => {
          console.warn(`Failed loading model from ${url}, attempting fallback:`, error);
          if (url === primaryUrl) {
            loadModel(fallbackUrl);
          } else {
            console.error('All model loading attempts failed:', error);
            setLoadError('Não foi possível carregar o modelo 3D.');
            setIsLoading(false);
          }
        }
      );
    };

    loadModel(primaryUrl);

    // 9. Interactive mouse / touch drag controls
    let isDragging = false;
    let previousPointerX = 0;
    let dragVelocityX = 0;
    let targetRotationY = 0;

    const handlePointerDown = (e: PointerEvent) => {
      isDragging = true;
      previousPointerX = e.clientX;
      dragVelocityX = 0;
      setIsInteracting(true);
    };

    const handlePointerMove = (e: PointerEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - previousPointerX;
      previousPointerX = e.clientX;
      dragVelocityX = deltaX * 0.008;
      targetRotationY += dragVelocityX;
    };

    const handlePointerUp = () => {
      isDragging = false;
      setIsInteracting(false);
    };

    container.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);

    // 10. Responsive resize observer
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      if (newWidth === 0 || newHeight === 0) return;

      camera.aspect = newWidth / newHeight;
      if (newWidth < 480) {
        camera.position.z = 5.2;
      } else if (newWidth < 768) {
        camera.position.z = 4.8;
      } else {
        camera.position.z = 4.5;
      }
      camera.updateProjectionMatrix();

      renderer.setSize(newWidth, newHeight);
    };

    const resizeObserver = new ResizeObserver(() => handleResize());
    resizeObserver.observe(container);
    handleResize();

    // 11. Animation Loop with continuous slow Y-rotation & software-WebGL pacing
    let lastTime = performance.now();
    const baseRotationSpeed = 0.55; // radians per second

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl?.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl?.flush?.();
      const poll = () => {
        if (!sync) {
          pollTimerId = window.setTimeout(cb, 40);
          return;
        }
        const state = gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          pollTimerId = window.setTimeout(poll, 5);
        } else {
          gl.deleteSync(sync);
          pollTimerId = window.setTimeout(cb, 40);
        }
      };
      pollTimerId = window.setTimeout(poll, 5);
    }

    const tick = () => {
      if (isDisposed) return;

      const now = performance.now();
      const delta = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      // Continuous slow rotation on Y
      if (!isDragging) {
        dragVelocityX *= 0.92;
        targetRotationY += dragVelocityX;
        modelGroup.rotation.y += baseRotationSpeed * delta + targetRotationY * 0.1;
        targetRotationY *= 0.9;
      } else {
        modelGroup.rotation.y += targetRotationY;
        targetRotationY = 0;
      }

      // Classic spinning barber stripes (local Z in FBX converted space)
      if (innerStripesNode) {
        innerStripesNode.rotation.z += 1.0 * delta;
      }

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        animFrameId = requestAnimationFrame(tick);
      }
    };

    tick();

    // Cleanup
    return () => {
      isDisposed = true;
      cancelAnimationFrame(animFrameId);
      clearTimeout(pollTimerId);
      resizeObserver.disconnect();

      container.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);

      renderer.dispose();
      shadowGeo.dispose();
      shadowMat.dispose();
      shadowTexture.dispose();

      modelGroup.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const mesh = child as THREE.Mesh;
          mesh.geometry?.dispose();
          if (Array.isArray(mesh.material)) {
            mesh.material.forEach((m) => m?.dispose());
          } else {
            mesh.material?.dispose();
          }
        }
      });

      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div className={`relative w-full select-none ${className}`}>
      {/* 3D Canvas Mount Container */}
      <div
        ref={mountRef}
        className="w-full h-full min-h-[350px] sm:min-h-[420px] lg:min-h-[500px] xl:min-h-[560px] cursor-grab active:cursor-grabbing touch-pan-y"
        style={{ touchAction: 'pan-y' }}
        title="Poste de barbeiro 3D interativo — arraste para girar"
      />

      {/* Loading state indicator */}
      {isLoading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          <div className="w-10 h-10 rounded-full border-2 border-zinc-700 border-t-[#c5a059] animate-spin mb-3" />
          <span className="text-[11px] uppercase tracking-widest text-zinc-400 font-mono">
            Carregando 3D...
          </span>
        </div>
      )}

      {/* Error fallback */}
      {loadError && (
        <div className="absolute inset-0 flex items-center justify-center p-4 text-center">
          <p className="text-xs text-zinc-400">{loadError}</p>
        </div>
      )}

      {/* Interactive Micro-badge Overlay */}
      <div className="absolute bottom-2 right-3 pointer-events-none flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-zinc-950/70 backdrop-blur-md border border-zinc-800/80 text-[10px] text-zinc-400 shadow-md">
        <RotateCw className={`w-3 h-3 text-[#c5a059] ${isInteracting ? 'animate-spin' : ''}`} />
        <span className="hidden sm:inline">Arraste para girar</span>
        <span className="sm:hidden">3D Interativo</span>
      </div>

      {/* Warm Golden Ambient Glow Behind Pole */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-64 sm:w-60 sm:h-80 bg-[#c5a059]/15 rounded-full blur-[80px] pointer-events-none -z-10"
        aria-hidden="true"
      />
    </div>
  );
};
