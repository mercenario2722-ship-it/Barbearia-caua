import React from 'react';
import { MessageCircle, Clock, ShieldCheck, ArrowUpRight, Sparkles } from 'lucide-react';
import { CAUA_DISPLAY_PHONE, buildWhatsAppLink, getBookingMessage } from '../utils/whatsapp.ts';
import { TiltCard } from './TiltCard.tsx';
import { FadeInUp } from './FadeInUp.tsx';

export const CtaSection: React.FC = () => {
  const whatsappUrl = buildWhatsAppLink(getBookingMessage());

  return (
    <section className="py-28 bg-[#09090c]/50 backdrop-blur-[1px] border-t border-zinc-900/80 relative overflow-hidden">
      {/* Ambient warm glow integrated with global background */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div 
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[650px] h-[350px] bg-[#c5a059]/10 rounded-full blur-[150px]" 
          aria-hidden="true" 
        />
      </div>

      <FadeInUp>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <TiltCard maxTilt={4} glare={true} scale={1.01}>
          <div className="p-8 sm:p-14 rounded-3xl bg-zinc-950/85 backdrop-blur-2xl border border-gold-glow text-center shadow-[0_20px_60px_rgba(0,0,0,0.9)]">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-zinc-900/90 border border-zinc-800 text-[#c5a059] text-xs font-bold tracking-widest uppercase mb-6 shadow-inner">
              <Clock className="w-3.5 h-3.5" />
              <span>Atendimento com Hora Marcada</span>
            </div>

            <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white mb-6 text-balance leading-tight">
              Pronto para elevar o seu estilo com o Cauã?
            </h2>

            <p className="text-zinc-300 text-base sm:text-lg max-w-2xl mx-auto mb-10 leading-relaxed text-pretty font-normal">
              Sem filas e sem espera. Garanta o seu horário pelo canal oficial do WhatsApp e experimente um corte com acabamento milimétrico no Park Rinald.
            </p>

            {/* WhatsApp CTA Action */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-10 py-4 text-xs sm:text-sm font-bold tracking-wider uppercase text-zinc-950 bg-gradient-to-r from-[#e5c278] via-[#c5a059] to-[#b38e47] hover:brightness-110 active:scale-[0.98] rounded-sm transition-all shadow-[0_8px_30px_rgba(197,160,89,0.35)] hover:shadow-[0_10px_40px_rgba(197,160,89,0.5)] focus:outline-none focus:ring-2 focus:ring-[#c5a059]"
              >
                <MessageCircle className="w-5 h-5 fill-current" />
                <span>Agendar meu horário no WhatsApp</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>

            {/* Official Number & Direct Contact info */}
            <div className="mt-10 pt-6 border-t border-zinc-800/80 flex flex-col sm:flex-row items-center justify-center gap-6 text-xs text-zinc-400 font-medium">
              <div className="flex items-center gap-2">
                <span className="text-zinc-400">Contato Oficial:</span>
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white font-mono font-bold hover:text-[#c5a059] transition-colors"
                >
                  {CAUA_DISPLAY_PHONE}
                </a>
              </div>
              <span className="hidden sm:inline text-zinc-700" aria-hidden="true">·</span>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#c5a059]" />
                <span className="text-zinc-300">Park Rinald, Varginha — MG</span>
              </div>
            </div>
          </div>
        </TiltCard>
      </div>
      </FadeInUp>
    </section>
  );
};
