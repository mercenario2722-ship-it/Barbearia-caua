import React from 'react';
import { CheckCircle2, ArrowRight, Sparkles } from 'lucide-react';
import { buildWhatsAppLink, getBookingMessage } from '../utils/whatsapp.ts';
import { TiltCard } from './TiltCard.tsx';
import { FadeInUp } from './FadeInUp.tsx';

export const About: React.FC = () => {
  const whatsappUrl = buildWhatsAppLink(getBookingMessage());

  const highlights = [
    'Atenção individualizada a cada formato de rosto e textura de cabelo',
    'Técnica consistente com degradê suave, sem marcas e alinhamento preciso',
    'Ambiente tranquilo e exclusivo no Park Rinald, sem pressa nem barulho excessivo',
    'Produtos e lâminas selecionados para preservar a saúde do couro cabeludo e pele',
  ];

  return (
    <section id="sobre" className="py-28 bg-[#09090c]/50 backdrop-blur-[1px] border-t border-zinc-900/80 relative scroll-mt-20 overflow-hidden">
      {/* Ambient lighting accents */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
        <div 
          className="absolute top-1/2 left-10 w-[500px] h-[400px] bg-[#c5a059]/5 rounded-full blur-[140px]" 
          aria-hidden="true" 
        />
      </div>

      <FadeInUp>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Images Grid with 3D Depth (5 cols) */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <TiltCard maxTilt={7} glare={true} scale={1.03}>
                <div className="rounded-2xl overflow-hidden border border-zinc-700/80 shadow-[0_15px_35px_-5px_rgba(0,0,0,0.8)] bg-zinc-950 aspect-[3/4]">
                  <img
                    src="/assets/aistudio/IMG_8853_d708e5f7.jpeg"
                    alt="Técnica de tesoura e alinhamento por Cauã"
                    className="w-full h-full object-cover filter grayscale contrast-115 brightness-95"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </TiltCard>

              <div className="p-4 rounded-xl bg-zinc-950/80 backdrop-blur-md border border-zinc-800/80 text-center shadow-lg">
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#c5a059] block">
                  Compromisso
                </span>
                <p className="font-heading text-sm font-bold text-white mt-0.5">
                  Artesanato & Cuidado
                </p>
              </div>
            </div>

            <div className="space-y-4 pt-8">
              <div className="p-4 rounded-xl bg-zinc-950/80 backdrop-blur-md border border-zinc-800/80 text-center shadow-lg">
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#c5a059] block">
                  Estrutura
                </span>
                <p className="font-heading text-sm font-bold text-white mt-0.5">
                  Bancada de Elite
                </p>
              </div>

              <TiltCard maxTilt={7} glare={true} scale={1.03}>
                <div className="rounded-2xl overflow-hidden border border-zinc-700/80 shadow-[0_15px_35px_-5px_rgba(0,0,0,0.8)] bg-zinc-950 aspect-[3/4]">
                  <img
                    src="/assets/aistudio/IMG_8854_09e6e85b.jpeg"
                    alt="Bancada profissional do Cauã com produtos selecionados"
                    className="w-full h-full object-cover filter contrast-110 brightness-95"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </TiltCard>
            </div>
          </div>

          {/* Text Content (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900/80 border border-zinc-800 text-[#c5a059] text-xs font-semibold tracking-[0.2em] uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Sobre o Barbeiro</span>
            </div>

            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight text-balance">
              Mais que um corte.{' '}
              <span className="block text-zinc-300">
                Uma experiência feita para você.
              </span>
            </h2>

            <p className="text-zinc-300 text-base sm:text-lg leading-relaxed font-normal">
              O atendimento do <strong className="text-white font-bold">Cauã</strong> foi desenhado para quem valoriza pontualidade, precisão e uma conversa sincera sobre qual estilo realmente valoriza sua imagem.
            </p>

            <p className="text-zinc-400 text-sm sm:text-base leading-relaxed">
              Aqui, cada cliente recebe atenção dedicada do início ao fim. O corte não é apenas reproduzir uma referência qualquer da internet, mas entender a anatomia, o caimento natural dos seus fios e a rotina do seu dia a dia para garantir um visual impecável até o próximo retorno.
            </p>

            {/* Authentic values list with glass backing */}
            <div className="space-y-3 pt-2">
              {highlights.map((highlight, i) => (
                <div key={i} className="flex items-start gap-3 p-2.5 rounded-lg bg-zinc-950/40 border border-zinc-800/60">
                  <CheckCircle2 className="w-5 h-5 text-[#c5a059] shrink-0 mt-0.5" />
                  <span className="text-sm text-zinc-300 leading-snug font-medium">
                    {highlight}
                  </span>
                </div>
              ))}
            </div>

            <div className="pt-6 flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2.5 px-7 py-3.5 text-xs font-bold uppercase tracking-wider text-zinc-950 bg-gradient-to-r from-[#e5c278] via-[#c5a059] to-[#b38e47] hover:brightness-110 active:scale-[0.98] rounded-sm transition-all shadow-md focus:outline-none focus:ring-2 focus:ring-[#c5a059]"
              >
                <span>Agendar com o Cauã</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <span className="text-xs text-zinc-400 font-medium">
                Atendimento com hora marcada no Park Rinald
              </span>
            </div>
          </div>
        </div>
      </div>
      </FadeInUp>
    </section>
  );
};
