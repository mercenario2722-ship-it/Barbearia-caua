import React, { useState, useEffect, useCallback } from 'react';
import { GALLERY_PHOTOS, GalleryPhoto } from '../data/barbershop.ts';
import { X, ChevronLeft, ChevronRight, Maximize2, MessageCircle, Sparkles } from 'lucide-react';
import { buildWhatsAppLink } from '../utils/whatsapp.ts';
import { TiltCard } from './TiltCard.tsx';
import { FadeInUp } from './FadeInUp.tsx';

export const Gallery: React.FC = () => {
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState<number | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'Todas as Fotos' },
    { id: 'cortes', label: 'Cortes & Fades' },
    { id: 'equipamentos', label: 'Arsenal & Máquinas' },
    { id: 'espaco', label: 'Espaço & Ambiente' },
  ];

  const filteredPhotos = filterCategory === 'all'
    ? GALLERY_PHOTOS
    : GALLERY_PHOTOS.filter((p) => p.category === filterCategory);

  const activePhoto: GalleryPhoto | null =
    selectedPhotoIndex !== null ? filteredPhotos[selectedPhotoIndex] : null;

  const handleNext = useCallback(() => {
    if (selectedPhotoIndex === null) return;
    setSelectedPhotoIndex((prev) => (prev! + 1) % filteredPhotos.length);
  }, [selectedPhotoIndex, filteredPhotos.length]);

  const handlePrev = useCallback(() => {
    if (selectedPhotoIndex === null) return;
    setSelectedPhotoIndex((prev) => (prev! - 1 + filteredPhotos.length) % filteredPhotos.length);
  }, [selectedPhotoIndex, filteredPhotos.length]);

  const handleClose = useCallback(() => {
    setSelectedPhotoIndex(null);
  }, []);

  // Keyboard navigation (Esc, ArrowLeft, ArrowRight)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedPhotoIndex === null) return;
      if (e.key === 'Escape') handleClose();
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedPhotoIndex, handleClose, handleNext, handlePrev]);

  // Lock body scroll when modal is open
  useEffect(() => {
    if (selectedPhotoIndex !== null) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [selectedPhotoIndex]);

  return (
    <section id="galeria" className="py-28 bg-[#08080a]/50 backdrop-blur-[1px] border-t border-zinc-900/80 relative scroll-mt-20 overflow-hidden">
      {/* Ambient background glow */}
      <div 
        className="absolute top-1/4 -left-32 w-[550px] h-[550px] bg-[#c5a059]/5 rounded-full blur-[160px] pointer-events-none" 
        aria-hidden="true" 
      />
      <div 
        className="absolute bottom-10 right-0 w-[450px] h-[450px] bg-zinc-800/10 rounded-full blur-[130px] pointer-events-none" 
        aria-hidden="true" 
      />

      <FadeInUp>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-900/80 border border-zinc-800 text-[#c5a059] text-xs font-semibold tracking-[0.2em] uppercase mb-4">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Portfólio & Detalhes</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Galeria de Cortes & Artesanato
            </h2>
          </div>
          <p className="text-zinc-300 text-sm sm:text-base max-w-md leading-relaxed">
            Fotos reais do trabalho executado pelo Cauã, do maquinário de elite ao ambiente contemporâneo no Park Rinald.
          </p>
        </div>

        {/* Filter buttons */}
        <div className="flex flex-wrap items-center gap-2 mb-10 pb-2 border-b border-zinc-800/60">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setFilterCategory(cat.id);
                setSelectedPhotoIndex(null);
              }}
              className={`px-4 py-2 text-xs sm:text-sm font-semibold rounded-md transition-all focus:outline-none focus-visible:ring-1 focus-visible:ring-[#c5a059] ${
                filterCategory === cat.id
                  ? 'bg-gradient-to-r from-[#e5c278] to-[#c5a059] text-zinc-950 font-bold shadow-[0_4px_15px_rgba(197,160,89,0.25)]'
                  : 'text-zinc-300 hover:text-white bg-zinc-900/70 hover:bg-zinc-800/80 border border-zinc-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Bento Gallery Grid with 3D Tilt */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPhotos.map((photo, index) => {
            const isTall = index === 0 || index === 2 || index === 5;

            return (
              <TiltCard
                key={photo.id}
                maxTilt={6}
                glare={true}
                scale={1.03}
                className={isTall ? 'sm:row-span-2' : ''}
              >
                <div
                  onClick={() => setSelectedPhotoIndex(index)}
                  className={`group relative overflow-hidden rounded-2xl bg-zinc-950 border border-zinc-800/90 hover:border-[#c5a059]/60 transition-all duration-300 cursor-pointer shadow-[0_15px_35px_-10px_rgba(0,0,0,0.8)] h-full ${
                    isTall ? 'aspect-[3/4]' : 'aspect-square'
                  }`}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      setSelectedPhotoIndex(index);
                    }
                  }}
                  aria-label={`Ver imagem ampliada: ${photo.title}`}
                >
                  <img
                    src={photo.src}
                    alt={photo.title}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out filter brightness-[0.93] group-hover:brightness-100"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />

                  {/* Scrim Overlay */}
                  <div 
                    className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-85 group-hover:opacity-95 transition-opacity"
                    aria-hidden="true" 
                  />

                  {/* Expand Icon Button */}
                  <div className="absolute top-4 right-4 w-10 h-10 rounded-full bg-zinc-950/80 backdrop-blur-md flex items-center justify-center text-zinc-300 group-hover:text-[#c5a059] group-hover:scale-110 transition-all opacity-0 group-hover:opacity-100 border border-zinc-700/70 shadow-lg">
                    <Maximize2 className="w-4 h-4" />
                  </div>

                  {/* Content Overlay */}
                  <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-1 group-hover:translate-y-0 transition-transform">
                    <span className="text-[10px] font-bold tracking-widest uppercase text-[#c5a059] block mb-1">
                      {photo.categoryLabel}
                    </span>
                    <h3 className="font-heading text-lg sm:text-xl font-bold text-white group-hover:text-zinc-100">
                      {photo.title}
                    </h3>
                    <p className="text-zinc-400 text-xs mt-1 line-clamp-2">
                      {photo.caption}
                    </p>
                  </div>
                </div>
              </TiltCard>
            );
          })}
        </div>

        {/* Gallery bottom callout */}
        <div className="mt-14 text-center">
          <p className="text-xs text-zinc-400 font-medium">
            Trabalhos autorais realizados por Cauã no bairro Park Rinald, Varginha - MG.
          </p>
        </div>
      </div>
      </FadeInUp>

      {/* Lightbox Modal with 3D Depth */}
      {activePhoto && selectedPhotoIndex !== null && (
        <div
          className="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 sm:p-6"
          onClick={handleClose}
          role="dialog"
          aria-modal="true"
          aria-label={activePhoto.title}
        >
          {/* Top Bar with counter & close */}
          <div
            className="absolute top-4 left-4 right-4 flex items-center justify-between z-10"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-xs font-mono font-medium text-zinc-300 tracking-wider bg-zinc-900/90 px-3.5 py-1.5 rounded-full border border-zinc-700/80">
              {selectedPhotoIndex + 1} / {filteredPhotos.length}
            </div>

            <button
              onClick={handleClose}
              className="p-2.5 rounded-full bg-zinc-900/90 text-zinc-300 hover:text-white hover:bg-zinc-800 border border-zinc-700/80 transition-colors focus:outline-none focus:ring-2 focus:ring-[#c5a059]"
              aria-label="Fechar visualização"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Navigation Controls */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              handlePrev();
            }}
            className="absolute left-4 top-1/2 -translate-y-1/2 p-3.5 rounded-full bg-zinc-900/90 hover:bg-zinc-800 text-white border border-zinc-700/80 transition-all hover:scale-110 z-10 hidden sm:flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-[#c5a059]"
            aria-label="Foto anterior"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              handleNext();
            }}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-3.5 rounded-full bg-zinc-900/90 hover:bg-zinc-800 text-white border border-zinc-700/80 transition-all hover:scale-110 z-10 hidden sm:flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-[#c5a059]"
            aria-label="Próxima foto"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Modal Content Card */}
          <div
            className="max-w-4xl w-full max-h-[88vh] flex flex-col md:flex-row bg-[#0c0c0f] rounded-2xl overflow-hidden border border-zinc-700/80 shadow-[0_25px_60px_rgba(0,0,0,0.95)]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Image Pane */}
            <div className="relative md:w-3/5 bg-black flex items-center justify-center overflow-hidden min-h-[300px] max-h-[55vh] md:max-h-[80vh]">
              <img
                src={activePhoto.src}
                alt={activePhoto.title}
                className="max-h-full max-w-full object-contain"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Info Pane */}
            <div className="md:w-2/5 p-6 sm:p-8 flex flex-col justify-between border-t md:border-t-0 md:border-l border-zinc-800 bg-[#0e0e12]">
              <div>
                <span className="text-xs font-bold tracking-widest uppercase text-[#c5a059] block mb-2">
                  {activePhoto.categoryLabel}
                </span>

                <h3 className="font-heading text-2xl font-bold text-white mb-3">
                  {activePhoto.title}
                </h3>

                <p className="text-zinc-300 text-sm leading-relaxed mb-6 font-normal">
                  {activePhoto.caption}
                </p>

                <div className="py-4 border-y border-zinc-800/80 text-xs text-zinc-400 space-y-1.5 font-medium">
                  <p>
                    <strong className="text-zinc-200">Local:</strong> Barbearia do Cauã, Park Rinald
                  </p>
                  <p>
                    <strong className="text-zinc-200">Atendimento:</strong> Varginha — MG
                  </p>
                </div>
              </div>

              {/* Direct Booking for this Style */}
              <div className="pt-6">
                <a
                  href={buildWhatsAppLink(
                    `Olá, Cauã! Vi a foto "${activePhoto.title}" no seu portfólio e gostaria de fazer esse estilo. Quais horários tem disponíveis?`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 text-xs font-bold uppercase tracking-wider text-zinc-950 bg-gradient-to-r from-[#e5c278] via-[#c5a059] to-[#b38e47] hover:brightness-110 rounded-sm transition-all shadow-md focus:outline-none focus:ring-2 focus:ring-[#c5a059]"
                >
                  <MessageCircle className="w-4 h-4 fill-current" />
                  <span>Quero um corte assim</span>
                </a>
                <p className="text-[11px] text-zinc-400 text-center mt-2 font-medium">
                  Abre conversa direta no WhatsApp com o Cauã
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
