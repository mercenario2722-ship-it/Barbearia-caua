/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { Diferenciais } from './components/Diferenciais.tsx';
import { RitualSection } from './components/RitualSection.tsx';
import { Services } from './components/Services.tsx';
import { Gallery } from './components/Gallery.tsx';
import { About } from './components/About.tsx';
import { Location } from './components/Location.tsx';
import { FaqSection } from './components/FaqSection.tsx';
import { CtaSection } from './components/CtaSection.tsx';
import { Footer } from './components/Footer.tsx';
import { FloatingWhatsApp } from './components/FloatingWhatsApp.tsx';
import { SiteBackground } from './components/SiteBackground.tsx';

export default function App() {
  return (
    <div className="min-h-screen text-zinc-100 flex flex-col font-sans selection:bg-[#c5a059] selection:text-black relative isolate">
      {/* Immersive Whole-Site Photographic Background with Illuminated Lamp */}
      <SiteBackground />

      {/* Top Navigation */}
      <Navbar />

      {/* Main Content Sections */}
      <main className="flex-1 relative z-10">
        <Hero />
        <Diferenciais />
        <RitualSection />
        <Services />
        <Gallery />
        <About />
        <Location />
        <FaqSection />
        <CtaSection />
      </main>

      {/* Footer */}
      <div className="relative z-10">
        <Footer />
      </div>

      {/* Quick Access Floating WhatsApp */}
      <FloatingWhatsApp />
    </div>
  );
}
