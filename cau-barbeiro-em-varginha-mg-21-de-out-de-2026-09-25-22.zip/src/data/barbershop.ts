export interface Service {
  id: string;
  name: string;
  category: 'corte' | 'barba' | 'combo' | 'acabamento';
  categoryLabel: string;
  description: string;
  price: number | 'consultar';
  durationMinutes: number;
  featured?: boolean;
}

export interface GalleryPhoto {
  id: string;
  src: string;
  title: string;
  category: 'cortes' | 'equipamentos' | 'espaco';
  categoryLabel: string;
  caption: string;
  aspect: 'portrait' | 'landscape' | 'square';
}

export const SERVICES: Service[] = [
  {
    id: 'corte-fade',
    name: 'Corte Degradê & Fade',
    category: 'corte',
    categoryLabel: 'Cabelo',
    description: 'Degradê suave (low, mid ou high fade), taper fade ou corte clássico na tesoura. Alinhamento milimétrico e acabamento impecável.',
    price: 35,
    durationMinutes: 45,
    featured: true,
  },
  {
    id: 'combo-completo',
    name: 'Combo Corte + Barba',
    category: 'combo',
    categoryLabel: 'Experiência Completa',
    description: 'A renovação visual completa. Corte de cabelo estruturado no seu estilo com barba desenhada, alinhada e finalizada.',
    price: 55,
    durationMinutes: 75,
    featured: true,
  },
  {
    id: 'barba-alinhamento',
    name: 'Barba & Alinhamento',
    category: 'barba',
    categoryLabel: 'Barba',
    description: 'Desenho de linhas na navalha, corte de volume com tesoura e máquina, hidratação dos fios e pós-barba calmante.',
    price: 25,
    durationMinutes: 35,
  },
  {
    id: 'acabamento-pezinho',
    name: 'Acabamento & Pezinho',
    category: 'acabamento',
    categoryLabel: 'Manutenção',
    description: 'Alinhamento dos contornos da nuca, costeletas e testa com navalha afiada para manter seu corte alinhado entre manutenções.',
    price: 15,
    durationMinutes: 20,
  },
  {
    id: 'sobrancelha-navalha',
    name: 'Sobrancelha na Navalha',
    category: 'acabamento',
    categoryLabel: 'Manutenção',
    description: 'Limpeza e desenho natural dos fios com navalha descartável, mantendo a harmonia e formato natural do rosto.',
    price: 10,
    durationMinutes: 15,
  },
  {
    id: 'corte-tesoura',
    name: 'Corte Exclusivo na Tesoura',
    category: 'corte',
    categoryLabel: 'Cabelo',
    description: 'Técnica de mechas e texturização 100% na tesoura para cabelos médios e compridos, preservando caimento e movimento natural.',
    price: 40,
    durationMinutes: 50,
  },
];

export const GALLERY_PHOTOS: GalleryPhoto[] = [
  {
    id: 'img-fade-execucao',
    src: '/assets/aistudio/IMG_8852_b8f56ab7.jpeg',
    title: 'Degradê de Alta Precisão',
    category: 'cortes',
    categoryLabel: 'Cortes & Fades',
    caption: 'Graduação limpa com transição suave da pele ao topo, respeitando o formato da cabeça.',
    aspect: 'portrait',
  },
  {
    id: 'img-tesoura-fio',
    src: '/assets/aistudio/IMG_8853_d708e5f7.jpeg',
    title: 'Texturização & Fio Laser',
    category: 'cortes',
    categoryLabel: 'Técnica & Tesoura',
    caption: 'Trabalho artesanal de tesoura sobre pente para criar textura e alinhamento impecável.',
    aspect: 'portrait',
  },
  {
    id: 'img-maquinas-ouro',
    src: '/assets/aistudio/IMG_8851_35fcdd32.jpeg',
    title: 'Equipamentos de Elite',
    category: 'equipamentos',
    categoryLabel: 'Equipamentos',
    caption: 'Maquinário de alta performance e tesouras afiadas para cortes suaves e sem puxões.',
    aspect: 'portrait',
  },
  {
    id: 'img-bancada-produtos',
    src: '/assets/aistudio/IMG_8854_09e6e85b.jpeg',
    title: 'Bancada & Finalizadores',
    category: 'equipamentos',
    categoryLabel: 'Equipamentos',
    caption: 'Estrutura completa com produtos selecionados para hidratação e fixação duradoura.',
    aspect: 'portrait',
  },
  {
    id: 'img-arsenal-laminas',
    src: '/assets/aistudio/IMG_8857_7195f8d1.jpeg',
    title: 'Arsenal & Ferramental',
    category: 'equipamentos',
    categoryLabel: 'Equipamentos',
    caption: 'Navalhetes, pentes graduados e lâminas descartáveis em cada atendimento.',
    aspect: 'square',
  },
  {
    id: 'img-espaco-mural',
    src: '/assets/aistudio/IMG_8858_391f3982.jpeg',
    title: 'Identidade & Espaço',
    category: 'espaco',
    categoryLabel: 'Ambiente',
    caption: 'Ambiente moderno no Park Rinald com iluminação cenográfica e identidade autoral.',
    aspect: 'portrait',
  },
  {
    id: 'img-barber-pole',
    src: '/assets/aistudio/IMG_8856_16ac1a45.jpeg',
    title: 'Tradição da Barbearia',
    category: 'espaco',
    categoryLabel: 'Ambiente',
    caption: 'O símbolo clássico da barbearia reinterpretado com sofisticação contemporânea.',
    aspect: 'square',
  },
];

export const DIFFERENTIALS = [
  {
    number: '01',
    title: 'Atendimento com Hora Marcada',
    description: 'Sem espera desnecessária em fila. Seu horário é 100% dedicado a você e ao seu estilo.',
  },
  {
    number: '02',
    title: 'Consultoria de Estilo',
    description: 'Antes de cortar, analisamos seu formato de rosto, tipo de cabelo e rotina para indicar o melhor corte.',
  },
  {
    number: '03',
    title: 'Precisão Milimétrica',
    description: 'Domínio de técnicas modernas de degradê, tesoura e navalha para um acabamento limpo e duradouro.',
  },
  {
    number: '04',
    title: 'Higiene & Equipamentos Profissionais',
    description: 'Lâminas 100% descartáveis para cada cliente, materiais higienizados e máquinas de linha profissional.',
  },
];
